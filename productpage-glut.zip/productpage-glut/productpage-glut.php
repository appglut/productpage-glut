<?php
/*
 * Plugin Name: ProductPage Glut- Builder for WooCommerce
 * Description: Complete WooCommerce builder with 9 powerful modules including product page builder, cart page, checkout editor, order complete, wishlist, product custom fields, swatches, badges, and comparison for professional e-commerce sites
 * Version: 1.0.0
 * Author: AppGlut
 * Author URI: https://www.appglut.com
 * Plugin URI: https://wordpress.org/plugins/productpageglut/
 * License: GPLv2 or later
 * Text Domain: productpageglut
 * Domain Path: /languages
 * Requires Plugins: woocommerce
 */

defined( 'ABSPATH' ) or die;

define( 'PRODUCTPAGEGLUT_NAME', 'Productpageglut' );
define( 'PRODUCTPAGEGLUT_VERSION', '1.7.7' );
define( 'PRODUCTPAGEGLUT_BASENAME', plugin_basename( __FILE__ ) );
define( 'PRODUCTPAGEGLUT_PATH', plugin_dir_path( __FILE__ ) );
define( 'PRODUCTPAGEGLUT_URL', plugin_dir_url( __FILE__ ) );
define( 'PRODUCTPAGEGLUT_ADMIN_IMAGES', plugin_dir_url( __FILE__ ) . 'src/library/model/assets/images/' );
define( 'PRODUCTPAGEGLUT_DIRNAME', dirname( plugin_basename( __FILE__ ) ) );
define( 'PRODUCTPAGEGLUT_SLUG', dirname( plugin_basename( __FILE__ ) ) );

// Pro upgrade URLs
define( 'PRODUCTPAGEGLUT_PRICING_URL', 'https://www.appglut.com' );
define( 'PRODUCTPAGEGLUT_PRO_URL', 'https://www.appglut.com' );
define( 'PRODUCTPAGEGLUT_UPGRADE_URL', 'https://www.appglut.com' );

// Autoloader for class loading
require __DIR__ . '/autoloader.php';

// Load WelcomePage class early (for admin redirect after activation)
if ( is_admin() ) {
	require_once PRODUCTPAGEGLUT_PATH . 'src/WelcomePage.php';
}


// Hook into WooCommerce initialization
add_action( 'woocommerce_init', 'productpageglut_plugin_initialize' );


function productpageglut_plugin_initialize() {
	// Ensure that WooCommerce is loaded before proceeding
	if ( class_exists( 'WooCommerce' ) ) {
		// Run Productpageglut initialization
		Productpageglut\ProductpageglutBase::get_instance();
		// Initialize Module Manager

	}
}

// Add welcome page menu
add_action( 'admin_menu', 'productpageglut_add_welcome_menu', 99 );

function productpageglut_add_welcome_menu() {
	add_submenu_page(
		null, // Parent slug - null to hide from menu
		esc_html__( 'Welcome', 'productpageglut' ),
		esc_html__( 'Welcome', 'productpageglut' ),
		'manage_options',
		'productpageglut-welcome',
		'productpageglut_render_welcome_page'
	);
}

function productpageglut_render_welcome_page() {
	$welcome_page = new \Productpageglut\WelcomePage();
	$welcome_page->render_welcome_content();
}

// Register activation hook with redirect to welcome page
register_activation_hook( __FILE__, 'productpageglut_plugin_activation' );

function productpageglut_plugin_activation() {
	// Set transient for redirect
	set_transient( 'productpageglut_activation_redirect', true, 30 );

	// Set option for first activation redirect
	update_option( 'productpageglut_first_activation', get_option( 'productpageglut_first_activation', 0 ) + 1 );
}

// Handle redirect after activation
add_action( 'admin_init', 'productpageglut_redirect_after_activation' );

function productpageglut_redirect_after_activation() {
	// Check if we need to redirect
	if ( get_transient( 'productpageglut_activation_redirect' ) ) {
		delete_transient( 'productpageglut_activation_redirect' );

		// Only redirect if it's not a bulk activation
		if ( isset( $_GET['activate-multi'] ) ) {
			return;
		}

		// Redirect to welcome page
		wp_safe_redirect( admin_url( 'admin.php?page=productpageglut-welcome' ) );
		exit;
	}
}


