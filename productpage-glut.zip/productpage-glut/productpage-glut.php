<?php
/**
 * Plugin Name: ProductPageGlut - Product Page Builder for WooCommerce
 * Plugin URI: https://github.com/appglut/productpage-glut
 * Description: Complete WooCommerce product page builder with custom fields, swatches, badges, wishlist, comparison, quick view, and more for professional e-commerce sites
 * Version: 1.7.7
 * Author: AppGlut
 * Author URI: https://www.appglut.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: productbaseglut
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 */

defined( 'ABSPATH' ) or die;

define( 'PRODUCTBASEGLUT_NAME', 'Productbaseglut' );
define( 'PRODUCTBASEGLUT_VERSION', '1.7.7' );
define( 'PRODUCTBASEGLUT_BASENAME', plugin_basename( __FILE__ ) );
define( 'PRODUCTBASEGLUT_PATH', plugin_dir_path( __FILE__ ) );
define( 'PRODUCTBASEGLUT_URL', plugin_dir_url( __FILE__ ) );
define( 'PRODUCTBASEGLUT_ADMIN_IMAGES', plugin_dir_url( __FILE__ ) . 'src/library/model/assets/images/' );
define( 'PRODUCTBASEGLUT_DIRNAME', dirname( plugin_basename( __FILE__ ) ) );
define( 'PRODUCTBASEGLUT_SLUG', dirname( plugin_basename( __FILE__ ) ) );

// Pro upgrade URLs
define( 'PRODUCTBASEGLUT_PRICING_URL', 'https://www.appglut.com' );
define( 'PRODUCTBASEGLUT_PRO_URL', 'https://www.appglut.com' );
define( 'PRODUCTBASEGLUT_UPGRADE_URL', 'https://www.appglut.com' );

// Autoloader for class loading
require __DIR__ . '/autoloader.php';

// Load WelcomePage class early (for admin redirect after activation)
if ( is_admin() ) {
	require_once PRODUCTBASEGLUT_PATH . 'src/WelcomePage.php';
}

// Initialize IndividualMenu class (for standalone menu support)
if ( is_admin() ) {
	Productbaseglut\ProductpageglutIndividualMenu::get_instance();
}

// Hook into WooCommerce initialization
add_action( 'woocommerce_init', 'shopglut_plugin_initialize' );


function shopglut_plugin_initialize() {
	// Ensure that WooCommerce is loaded before proceeding
	if ( class_exists( 'WooCommerce' ) ) {
		// Run Productbaseglut initialization
		Productbaseglut\ShopGlutBase::get_instance();
		// Initialize Module Manager

	}
}

// Add welcome page menu
add_action( 'admin_menu', 'productbaseglut_add_welcome_menu', 99 );

function productbaseglut_add_welcome_menu() {
	add_submenu_page(
		null, // Parent slug - null to hide from menu
		esc_html__( 'Welcome', 'productbaseglut' ),
		esc_html__( 'Welcome', 'productbaseglut' ),
		'manage_options',
		'productbaseglut-welcome',
		'productbaseglut_render_welcome_page'
	);
}

function productbaseglut_render_welcome_page() {
	$welcome_page = new \Productbaseglut\WelcomePage();
	$welcome_page->render_welcome_content();
}

// Register activation hook with redirect to welcome page
register_activation_hook( __FILE__, 'productbaseglut_plugin_activation' );

function productbaseglut_plugin_activation() {
	// Set transient for redirect
	set_transient( 'productbaseglut_activation_redirect', true, 30 );

	// Set option for first activation redirect
	update_option( 'productbaseglut_first_activation', get_option( 'productbaseglut_first_activation', 0 ) + 1 );
}

// Handle redirect after activation
add_action( 'admin_init', 'productbaseglut_redirect_after_activation' );

function productbaseglut_redirect_after_activation() {
	// Check if we need to redirect
	if ( get_transient( 'productbaseglut_activation_redirect' ) ) {
		delete_transient( 'productbaseglut_activation_redirect' );

		// Only redirect if it's not a bulk activation
		if ( isset( $_GET['activate-multi'] ) ) {
			return;
		}

		// Redirect to welcome page
		wp_safe_redirect( admin_url( 'admin.php?page=productbaseglut-welcome' ) );
		exit;
	}
}
