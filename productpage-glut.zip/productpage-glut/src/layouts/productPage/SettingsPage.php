<?php
namespace Productpageglut\layouts\productPage;

class SettingsPage {

	public $menu_slug = 'productpage';


	public function loadSingleProductEditor() {
		// Set the current screen for proper meta box rendering
		// This ensures meta boxes registered for 'productpage' are rendered correctly
		global $current_screen, $wp_current_screen;

		// Store original screen
		$original_screen = $current_screen;

		// Set to productpage screen for meta box rendering
		set_current_screen( 'productpage' );

		$layout_id = ! wp_verify_nonce( isset( $_GET['layout_nonce_check'] ), 'layout_nonce_check' ) && isset( $_GET['layout_id'] ) ? absint( $_GET['layout_id'] ) : 1;

		$loading_gif = PRODUCTPAGEGLUT_URL . 'global-assets/images/loading-icon.png';

		do_action( 'save_shopg_layout_data', $layout_id );

		do_action( 'shopglut_layout_metaboxes', 'productbaseglut' );

		global $wpdb;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
		// Get layout data with caching
		$cache_key = "shopglut_layout_data_{$layout_id}";
		$layout_data = wp_cache_get( $cache_key, 'productpageglut_layouts' );

		if ( false === $layout_data ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Direct query required for custom table operation
			$layout_data = $wpdb->get_row(
				$wpdb->prepare( "SELECT layout_name, layout_template FROM {$wpdb->prefix}shopglut_single_product_layout WHERE id = %d", $layout_id )
			);
			wp_cache_set( $cache_key, $layout_data, 'productpageglut_layouts', 30 * MINUTE_IN_SECONDS );
		}

		if ( $layout_data ) {
			$layout_name = $layout_data->layout_name;
			$layout_template = $layout_data->layout_template;
		} else {
			?>
			<div class="wrap">
				<p><?php esc_html_e( 'No layout data found.', 'productbaseglut' ); ?></p>
			</div>
			<?php
			return;
		}

		?>
		<div id="shopg-layout-admin-settings" class="wrap layout_settings productbaseglut-cart_settings">

			<div class="loader-overlay" id="main-loader-overlay" style="display: flex; opacity: 1;">
				<div class="loader-container">
					<img src="<?php echo esc_url( $loading_gif ); ?>" alt="Loading Icon" class="loader-image">
					<div class="loader-dash-circle"></div>
				</div>
			</div>

	<form id="shopglut_shop_layouts" method="post" action="">

				<?php 
				$shopg_cpage_nonce = wp_create_nonce( 'shopg_singleproduct_layouts' ); 
				?>
				<input type="hidden" name="shopg_singleproduct_layouts_nonce" value="<?php echo esc_attr( $shopg_cpage_nonce ); ?>">
				<input type="hidden" name="shopg_shop_layoutid" id="shopg_shop_layoutid"
					value="<?php echo esc_attr( $layout_id ); ?>">

				<div class="shopglut_layout_contents">

					<div class="shopglut_editor_header">

						<div class="back-to-menu">

							<?php
							// Allow filtering the back button URL for integration with other plugins
							$back_page_slug = apply_filters( 'productpageglut_editor_back_page_slug', 'productpageglut_layouts' );
							$back_view = apply_filters( 'productpageglut_editor_back_view', 'product_page' );
							$back_url = admin_url( 'admin.php?page=' . $back_page_slug . '&view=' . $back_view );
							?>

							<a href="<?php echo esc_url( $back_url ); ?>"
								class="button button-secondary button-large">
								<i class="fa-solid fa-angles-left"></i>
								<?php echo esc_html__( 'Back To Menu', 'productbaseglut' ); ?>
							</a>

							<div class="clear"></div>
						</div>

						<div class="shopglut_layout_name">
							<label for="layout_name"><?php esc_html_e( 'Layout Name:', 'productbaseglut' ); ?></label>
							<input type="text" id="layout_name" name="layout_name"
								value="<?php echo esc_html( $layout_name ); ?>" />
							<input type="hidden" id="layout_template" name="layout_template"
								value="<?php echo esc_html( $layout_template ); ?>" />
						</div>

					</div>

					<div class="shopglut_layout_caption">
						<i class="fa-solid fa-circle-info"></i>
						<p class="info"><?php echo esc_html__( 'Info:', 'productbaseglut' ); ?></p>
						<p><?php echo esc_html__( 'Save Layout and see the update Preview', 'productbaseglut' ); ?></p>
					</div>

				<div id="shopg-notification-container"></div>

				</div>

                <div id="poststuff" class="productbaseglut-shoplayouts">
				
				<div id="post-body" class="metabox-holder columns-2">

						<div id="shopg-cart-layout-settings" class="postbox-container shopg-layout-settings-wrapper">
							<?php do_meta_boxes( $this->menu_slug, 'side', '' ); ?>
						</div>
			
					<button type="button" id="toggle-settings-button" class="toggle-button"><?php echo esc_html__('Hide', 'productbaseglut');  ?></button>

						<div class="submitbox" id="submitpost">
								<div id="singleProductLayout-publishing-action">
									<button type="button" id="productPage-reset-settings-button" class="btn btn-fullwidth btn-secondary"
									style=" background: #dc3545; color: white; border: none;">
									<?php echo esc_attr__( 'Reset', 'productbaseglut' ); ?>
									</button>
									<input type="submit" name="publish" id="publish" class="btn btn-fullwidth"
									value="<?php echo esc_attr__( 'Save Layout', 'productbaseglut' ); ?>">
									
								</div>
								<div class="clear"></div>
						</div>
						<div id="shopg-productPage-layout-container" class="shopg-admin-edit-panel">
							<div class="shopg-inside-loader">
								<div class="shopg-inside-loader-overlay">
									<div class="shopg-inside-loader-container">
										<img src="<?php echo esc_url( $loading_gif ); ?>" alt="Loading Icon"
											class="shopg-inside-loader-image">
										<div class="shopg-inside-loader-dash-circle"></div>
									</div>
								</div>
							</div>
							<?php do_meta_boxes( $this->menu_slug, 'normal', '' ); ?>
						</div>
				</div>

				</div>

				
	</div>

    </form>

		</div>
		<style>
			html.wp-toolbar {
				padding-top: 0px !important;
			}
		</style>

		<?php
	}

	public static function get_instance() {
		static $instance;

		if ( is_null( $instance ) ) {
			$instance = new self();
		}
		return $instance;
	}
}