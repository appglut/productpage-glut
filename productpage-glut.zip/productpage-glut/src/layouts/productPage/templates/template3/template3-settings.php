<?php
/**
 * Product Page template3 Specific Settings
 *
 * This file contains settings specifically designed for template3 product page layout.
 * template3 features:
 * - Product gallery with main image and thumbnails
 * - Product info with badges, title, rating, price, description
 * - Product options (color, size variations)
 * - Purchase section with quantity selector and add to cart
 * - Features section with service highlights
 * - Related products carousel
 */

if (!defined('ABSPATH')) {
    exit;
}

$SHOPG_singleproduct_STYLING = "shopg_singleproduct_settings_template3";


// Live Preview Section
AGSHOPGLUT::createMetabox(
	'shopg_single_product_live_preview',
	array(
		'title' => __( 'Preview - Demo Mode', 'productbaseglut' ),
		'post_type' => 'singleproduct',
		'context' => 'normal',
	)
);
AGSHOPGLUT::createSection(
	'shopg_single_product_live_preview',
	array(
		'fields' => array(
			array(
				'type' => 'preview',
			),
		),
	)
);

// Main Product Page Styling Settings
AGSHOPGLUT::createMetabox(
    $SHOPG_singleproduct_STYLING,
    array(
        'title' => esc_html__('template3 Product Page Settings', 'productbaseglut'),
        'post_type' => 'singleproduct',
        'context' => 'side',
    )
);


// Create fields array with overwrite option
$all_fields1 = array(
    array(
        'id'      => 'overwrite-all-products',
        'type'    => 'switcher',
        'title'   => __("Overwrite All Products", 'productbaseglut'),
        'default' => false
    ),
    array(
              'id' => 'overwrite-specific-products',
                'type'        => 'select_products',
                'title'       => __("Overwrite Specific Products", 'productbaseglut'),
                'placeholder' => __("Select products", 'productbaseglut'),
                'chosen'      => true,
                'multiple'    => true,
                'options' => 'select_products'
            ),
            array(
                'id' => 'single-product-settings',
                'type' => 'tabbed',
                'title' => __('template3 Configuration', 'productbaseglut'),
                'tabs' => array(

                    // ==================== PRODUCT GALLERY SETTINGS ====================
                    array(
                        'title' => __('Product Gallery', 'productbaseglut'),
                        'icon' => 'fas fa-images',
                        'fields' => array(

                            // Gallery Section Settings
                            array(
                                'id' => 'gallery_section_settings',
                                'type' => 'fieldset',
                                'title' => __('Gallery Section Layout', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'gallery_section_margin',
                                        'type' => 'slider',
                                        'title' => __('Gallery Section Bottom Margin', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 100,
                                        'step' => 5,
                                        'default' => 40,
                                    ),
                                ),
                            ),

                            // Main Image Settings
                            array(
                                'id' => 'main_image_settings',
                                'type' => 'fieldset',
                                'title' => __('Main Image Display', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'main_image_background',
                                        'type' => 'color',
                                        'title' => __('Main Image Background', 'productbaseglut'),
                                        'default' => '#f9fafb',
                                    ),
                                    array(
                                        'id' => 'main_image_border_radius',
                                        'type' => 'slider',
                                        'title' => __('Main Image Border Radius', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 20,
                                        'step' => 1,
                                        'default' => 8,
                                    ),
                                    array(
                                        'id' => 'main_image_border_color',
                                        'type' => 'color',
                                        'title' => __('Main Image Border Color', 'productbaseglut'),
                                        'default' => '#e5e7eb',
                                    ),
                                    array(
                                        'id' => 'main_image_border_width',
                                        'type' => 'slider',
                                        'title' => __('Main Image Border Width', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 5,
                                        'step' => 1,
                                        'default' => 1,
                                    ),
                                    array(
                                        'id' => 'main_image_padding',
                                        'type' => 'slider',
                                        'title' => __('Main Image Padding', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 50,
                                        'step' => 2,
                                        'default' => 14,
                                    ),
                                    array(
                                        'id' => 'main_image_margin_bottom',
                                        'type' => 'slider',
                                        'title' => __('Main Image Bottom Margin', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 50,
                                        'step' => 2,
                                        'default' => 20,
                                    ),
                                    array(
                                        'id' => 'main_image_object_fit',
                                        'type' => 'select',
                                        'title' => __('Main Image Object Fit', 'productbaseglut'),
                                        'options' => array(
                                            'cover' => __('Cover', 'productbaseglut'),
                                            'contain' => __('Contain', 'productbaseglut'),
                                            'fill' => __('Fill', 'productbaseglut'),
                                        ),
                                        'default' => 'cover',
                                    ),
                                ),
                            ),

                            // Thumbnail Settings
                            array(
                                'id' => 'thumbnail_settings',
                                'type' => 'fieldset',
                                'title' => __('Thumbnail Gallery', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'show_thumbnails',
                                        'type' => 'switcher',
                                        'title' => __('Show Thumbnail Gallery', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'thumbnail_border_radius',
                                        'type' => 'slider',
                                        'title' => __('Thumbnail Border Radius', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 15,
                                        'step' => 1,
                                        'default' => 6,
                                        'dependency' => array('show_thumbnails', '==', true),
                                    ),
                                    array(
                                        'id' => 'thumbnail_spacing',
                                        'type' => 'slider',
                                        'title' => __('Thumbnail Spacing', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 4,
                                        'max' => 20,
                                        'step' => 2,
                                        'default' => 8,
                                        'dependency' => array('show_thumbnails', '==', true),
                                    ),
                                    array(
                                        'id' => 'thumbnail_size',
                                        'type' => 'slider',
                                        'title' => __('Thumbnail Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 60,
                                        'max' => 150,
                                        'step' => 5,
                                        'default' => 80,
                                        'dependency' => array('show_thumbnails', '==', true),
                                    ),
                                    array(
                                        'id' => 'thumbnail_border_width',
                                        'type' => 'slider',
                                        'title' => __('Thumbnail Border Width', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 5,
                                        'step' => 1,
                                        'default' => 2,
                                        'dependency' => array('show_thumbnails', '==', true),
                                    ),
                                    array(
                                        'id' => 'thumbnail_border_color',
                                        'type' => 'color',
                                        'title' => __('Thumbnail Border Color', 'productbaseglut'),
                                        'default' => 'transparent',
                                        'dependency' => array('show_thumbnails', '==', true),
                                    ),
                                    array(
                                        'id' => 'thumbnail_active_border',
                                        'type' => 'color',
                                        'title' => __('Active Thumbnail Border', 'productbaseglut'),
                                        'default' => '#667eea',
                                        'dependency' => array('show_thumbnails', '==', true),
                                    ),
                                    array(
                                        'id' => 'thumbnail_hover_border',
                                        'type' => 'color',
                                        'title' => __('Thumbnail Hover Border', 'productbaseglut'),
                                        'default' => '#2563eb',
                                        'dependency' => array('show_thumbnails', '==', true),
                                    ),
                                    array(
                                        'id' => 'thumbnail_gallery_margin_top',
                                        'type' => 'slider',
                                        'title' => __('Thumbnail Gallery Top Margin', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 40,
                                        'step' => 2,
                                        'default' => 16,
                                        'dependency' => array('show_thumbnails', '==', true),
                                    ),
                                    array(
                                        'id' => 'thumbnail_alignment',
                                        'type' => 'select',
                                        'title' => __('Thumbnail Alignment', 'productbaseglut'),
                                        'options' => array(
                                            'flex-start' => __('Left', 'productbaseglut'),
                                            'center' => __('Center', 'productbaseglut'),
                                            'flex-end' => __('Right', 'productbaseglut'),
                                        ),
                                        'default' => 'flex-start',
                                        'dependency' => array('show_thumbnails', '==', true),
                                    ),
                                    array(
                                        'id' => 'thumbnail_hover_scale',
                                        'type' => 'slider',
                                        'title' => __('Thumbnail Hover Scale', 'productbaseglut'),
                                        'unit' => '',
                                        'min' => 1.0,
                                        'max' => 1.2,
                                        'step' => 0.01,
                                        'default' => 1.05,
                                        'dependency' => array('show_thumbnails', '==', true),
                                    ),
                                    array(
                                        'id' => 'thumbnail_object_fit',
                                        'type' => 'select',
                                        'title' => __('Thumbnail Object Fit', 'productbaseglut'),
                                        'options' => array(
                                            'cover' => __('Cover', 'productbaseglut'),
                                            'contain' => __('Contain', 'productbaseglut'),
                                            'fill' => __('Fill', 'productbaseglut'),
                                        ),
                                        'default' => 'cover',
                                        'dependency' => array('show_thumbnails', '==', true),
                                    ),
                                ),
                            ),
                        ),
                    ),

                    // ==================== PRODUCT INFO SETTINGS ====================
                    array(
                        'title' => __('Product Info', 'productbaseglut'),
                        'icon' => 'fas fa-info-circle',
                        'fields' => array(

                            // Product Badges Module
                            array(
                                'id' => 'badges_integration',
                                'type' => 'fieldset',
                                'title' => __('Product Badges Module', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'enable_badges',
                                        'type' => 'switcher',
                                        'title' => __('Enable Product Badges', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'badge_layout_id',
                                        'type' => 'select_badge_layouts',
                                        'title' => __('Select Badge Layout', 'productbaseglut'),
                                        'placeholder' => __('Select a badge layout', 'productbaseglut'),
                                        'default' => '',
                                        'dependency' => array('enable_badges', '==', true),
                                    ),
                                    array(
                                        'id' => 'badge_position',
                                        'type' => 'select',
                                        'title' => __('Badge Position', 'productbaseglut'),
                                        'options' => array(
                                            'on_product_image' => __('On Product Image', 'productbaseglut'),
                                            'before_product_title' => __('Before Product Title', 'productbaseglut'),
                                            'after_product_title' => __('After Product Title', 'productbaseglut'),
                                            'before_price' => __('Before Price', 'productbaseglut'),
                                        ),
                                        'default' => 'on_product_image',
                                        'dependency' => array('enable_badges', '==', true),
                                    ),
                                ),
                            ),

                             // Product Custom Fields Module
                            array(
                                'id' => 'custom_fields_integration',
                                'type' => 'fieldset',
                                'title' => __('Product Custom Fields Module', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'enable_custom_fields',
                                        'type' => 'switcher',
                                        'title' => __('Enable Custom Fields', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'custom_fields_layout_id',
                                        'type' => 'select_custom_fields',
                                        'title' => __('Select Custom Fields Layout', 'productbaseglut'),
                                        'placeholder' => __('Select a custom field', 'productbaseglut'),
                                        'default' => '',
                                        'dependency' => array('enable_custom_fields', '==', true),
                                    ),
                                    array(
                                        'id' => 'custom_fields_position',
                                        'type' => 'select',
                                        'title' => __('Custom Fields Position', 'productbaseglut'),
                                        'options' => array(
                                            'after_product_title' => __('After Product Title', 'productbaseglut'),
                                            'before_price' => __('Before Price', 'productbaseglut'),
                                            'after_description' => __('After Description', 'productbaseglut'),
                                            'after_add_to_cart' => __('After Add to Cart', 'productbaseglut'),
                                        ),
                                        'default' => 'after_description',
                                        'dependency' => array('enable_custom_fields', '==', true),
                                    ),
                                ),
                            ),

                            // Product Title
                            array(
                                'id' => 'product_title_settings',
                                'type' => 'fieldset',
                                'title' => __('Product Title', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'product_title_color',
                                        'type' => 'color',
                                        'title' => __('Title Color', 'productbaseglut'),
                                        'default' => '#111827',
                                    ),
                                    array(
                                        'id' => 'product_title_font_size',
                                        'type' => 'slider',
                                        'title' => __('Title Font Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 20,
                                        'max' => 48,
                                        'step' => 2,
                                        'default' => 32,
                                    ),
                                    array(
                                        'id' => 'product_title_font_weight',
                                        'type' => 'select',
                                        'title' => __('Title Font Weight', 'productbaseglut'),
                                        'options' => array(
                                            '400' => __('Normal', 'productbaseglut'),
                                            '500' => __('Medium', 'productbaseglut'),
                                            '600' => __('Semi Bold', 'productbaseglut'),
                                            '700' => __('Bold', 'productbaseglut'),
                                            '800' => __('Extra Bold', 'productbaseglut'),
                                        ),
                                        'default' => '700',
                                    ),
                                ),
                            ),

                            // Rating Section
                            array(
                                'id' => 'rating_settings',
                                'type' => 'fieldset',
                                'title' => __('Rating Section', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'show_rating',
                                        'type' => 'switcher',
                                        'title' => __('Show Product Rating', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'star_color',
                                        'type' => 'color',
                                        'title' => __('Star Color', 'productbaseglut'),
                                        'default' => '#fbbf24',
                                        'dependency' => array('show_rating', '==', true),
                                    ),
                                    array(
                                        'id' => 'rating_text_color',
                                        'type' => 'color',
                                        'title' => __('Rating Text Color', 'productbaseglut'),
                                        'default' => '#6b7280',
                                        'dependency' => array('show_rating', '==', true),
                                    ),
                                    array(
                                        'id' => 'rating_font_size',
                                        'type' => 'slider',
                                        'title' => __('Rating Font Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 12,
                                        'max' => 20,
                                        'step' => 1,
                                        'default' => 14,
                                        'dependency' => array('show_rating', '==', true),
                                    ),
                                ),
                            ),

                            // Price Section
                            array(
                                'id' => 'price_settings',
                                'type' => 'fieldset',
                                'title' => __('Price Display', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'current_price_color',
                                        'type' => 'color',
                                        'title' => __('Current Price Color', 'productbaseglut'),
                                        'default' => '#111827',
                                    ),
                                    array(
                                        'id' => 'current_price_font_size',
                                        'type' => 'slider',
                                        'title' => __('Current Price Font Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 20,
                                        'max' => 40,
                                        'step' => 2,
                                        'default' => 28,
                                    ),
                                    array(
                                        'id' => 'original_price_color',
                                        'type' => 'color',
                                        'title' => __('Original Price Color', 'productbaseglut'),
                                        'default' => '#9ca3af',
                                    ),
                                    array(
                                        'id' => 'discount_badge_color',
                                        'type' => 'color',
                                        'title' => __('Discount Badge Color', 'productbaseglut'),
                                        'default' => '#ef4444',
                                    ),
                                    array(
                                        'id' => 'discount_badge_text_color',
                                        'type' => 'color',
                                        'title' => __('Discount Badge Text Color', 'productbaseglut'),
                                        'default' => '#ffffff',
                                    ),
                                ),
                            ),

                            // Description Settings
                            array(
                                'id' => 'description_settings',
                                'type' => 'fieldset',
                                'title' => __('Product Description', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'show_description',
                                        'type' => 'switcher',
                                        'title' => __('Show Product Description', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'description_color',
                                        'type' => 'color',
                                        'title' => __('Description Text Color', 'productbaseglut'),
                                        'default' => '#6b7280',
                                        'dependency' => array('show_description', '==', true),
                                    ),
                                    array(
                                        'id' => 'description_font_size',
                                        'type' => 'slider',
                                        'title' => __('Description Font Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 12,
                                        'max' => 20,
                                        'step' => 1,
                                        'default' => 16,
                                        'dependency' => array('show_description', '==', true),
                                    ),
                                    array(
                                        'id' => 'description_line_height',
                                        'type' => 'slider',
                                        'title' => __('Description Line Height', 'productbaseglut'),
                                        'unit' => '',
                                        'min' => 1.2,
                                        'max' => 2.0,
                                        'step' => 0.1,
                                        'default' => 1.6,
                                        'dependency' => array('show_description', '==', true),
                                    ),
                                ),
                            ),
                        ),
                    ),

                    // ==================== PRODUCT ATTRIBUTES SETTINGS ====================
                    array(
                        'title' => __('Product Attributes', 'productbaseglut'),
                        'icon' => 'fas fa-cogs',
                        'fields' => array(

                            // Product Swatches Module
                            array(
                                'id' => 'swatches_integration',
                                'type' => 'fieldset',
                                'title' => __('Product Swatches Module', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'enable_swatches',
                                        'type' => 'switcher',
                                        'title' => __('Enable Product Swatches', 'productbaseglut'),
                                        'desc' => __('Replace default variation dropdowns with visual swatches', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'swatches_position',
                                        'type' => 'select',
                                        'title' => __('Swatches Position', 'productbaseglut'),
                                        'options' => array(
                                            'replace_attributes' => __('Replace Default Attributes', 'productbaseglut'),
                                            'after_attributes' => __('After Default Attributes', 'productbaseglut'),
                                            'before_add_to_cart' => __('Before Add to Cart', 'productbaseglut'),
                                        ),
                                        'default' => 'replace_attributes',
                                        'dependency' => array('enable_swatches', '==', true),
                                    ),
                                ),
                            ),

                        ),
                    ),

                    // ==================== PURCHASE SECTION SETTINGS ====================
                    array(
                        'title' => __('Purchase Section', 'productbaseglut'),
                        'icon' => 'fas fa-shopping-cart',
                        'fields' => array(

                            // Quantity Selector
                            array(
                                'id' => 'quantity_selector_settings',
                                'type' => 'fieldset',
                                'title' => __('Quantity Selector', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'quantity_button_background',
                                        'type' => 'color',
                                        'title' => __('Quantity Button Background', 'productbaseglut'),
                                        'default' => '#f3f4f6',
                                    ),
                                    array(
                                        'id' => 'quantity_button_text_color',
                                        'type' => 'color',
                                        'title' => __('Quantity Button Text Color', 'productbaseglut'),
                                        'default' => '#374151',
                                    ),
                                    array(
                                        'id' => 'quantity_input_background',
                                        'type' => 'color',
                                        'title' => __('Quantity Input Background', 'productbaseglut'),
                                        'default' => '#ffffff',
                                    ),
                                    array(
                                        'id' => 'quantity_input_border',
                                        'type' => 'color',
                                        'title' => __('Quantity Input Border', 'productbaseglut'),
                                        'default' => '#d1d5db',
                                    ),
                                    array(
                                        'id' => 'quantity_border_radius',
                                        'type' => 'slider',
                                        'title' => __('Quantity Control Border Radius', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 15,
                                        'step' => 1,
                                        'default' => 6,
                                    ),
                                ),
                            ),

                            // Add to Cart Button
                            array(
                                'id' => 'add_to_cart_settings',
                                'type' => 'fieldset',
                                'title' => __('Add to Cart Button', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'cart_button_background',
                                        'type' => 'color',
                                        'title' => __('Button Background Color', 'productbaseglut'),
                                        'default' => '#667eea',
                                    ),
                                    array(
                                        'id' => 'cart_button_text_color',
                                        'type' => 'color',
                                        'title' => __('Button Text Color', 'productbaseglut'),
                                        'default' => '#ffffff',
                                    ),
                                    array(
                                        'id' => 'cart_button_hover_background',
                                        'type' => 'color',
                                        'title' => __('Button Hover Background', 'productbaseglut'),
                                        'default' => '#5a67d8',
                                    ),
                                    array(
                                        'id' => 'cart_button_border_radius',
                                        'type' => 'slider',
                                        'title' => __('Button Border Radius', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 20,
                                        'step' => 1,
                                        'default' => 8,
                                    ),
                                    array(
                                        'id' => 'cart_button_font_size',
                                        'type' => 'slider',
                                        'title' => __('Button Font Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 14,
                                        'max' => 20,
                                        'step' => 1,
                                        'default' => 16,
                                    ),
                                    array(
                                        'id' => 'cart_button_font_weight',
                                        'type' => 'select',
                                        'title' => __('Button Font Weight', 'productbaseglut'),
                                        'options' => array(
                                            '400' => __('Normal', 'productbaseglut'),
                                            '500' => __('Medium', 'productbaseglut'),
                                            '600' => __('Semi Bold', 'productbaseglut'),
                                            '700' => __('Bold', 'productbaseglut'),
                                        ),
                                        'default' => '600',
                                    ),
                                ),
                            ),

                            // Wishlist Module
                            array(
                                'id' => 'wishlist_integration',
                                'type' => 'fieldset',
                                'title' => __('Wishlist Module', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'enable_wishlist',
                                        'type' => 'switcher',
                                        'title' => __('Enable Wishlist Button', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'wishlist_layout_id',
                                        'type' => 'select_wishlist_layouts',
                                        'title' => __('Select Wishlist Layout', 'productbaseglut'),
                                        'placeholder' => __('Select a wishlist layout', 'productbaseglut'),
                                        'default' => '',
                                        'dependency' => array('enable_wishlist', '==', true),
                                    ),
                                    array(
                                        'id' => 'wishlist_position',
                                        'type' => 'select',
                                        'title' => __('Wishlist Button Position', 'productbaseglut'),
                                        'options' => array(
                                            'after_add_to_cart' => __('After Add to Cart Button', 'productbaseglut'),
                                            'before_add_to_cart' => __('Before Add to Cart Button', 'productbaseglut'),
                                            'after_product_title' => __('After Product Title', 'productbaseglut'),
                                            'before_price' => __('Before Price', 'productbaseglut'),
                                        ),
                                        'default' => 'after_add_to_cart',
                                        'dependency' => array('enable_wishlist', '==', true),
                                    ),
                                ),
                            ),

                            // Product Comparison Module
                            array(
                                'id' => 'comparison_integration',
                                'type' => 'fieldset',
                                'title' => __('Product Comparison Module', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'enable_comparison',
                                        'type' => 'switcher',
                                        'title' => __('Enable Product Comparison', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'comparison_layout_id',
                                        'type' => 'select_comparison_layouts',
                                        'title' => __('Select Comparison Layout', 'productbaseglut'),
                                        'placeholder' => __('Select a comparison layout', 'productbaseglut'),
                                        'default' => '',
                                        'dependency' => array('enable_comparison', '==', true),
                                    ),
                                    array(
                                        'id' => 'comparison_position',
                                        'type' => 'select',
                                        'title' => __('Comparison Button Position', 'productbaseglut'),
                                        'options' => array(
                                            'after_add_to_cart' => __('After Add to Cart Button', 'productbaseglut'),
                                            'with_wishlist' => __('Next to Wishlist Button', 'productbaseglut'),
                                            'before_add_to_cart' => __('Before Add to Cart Button', 'productbaseglut'),
                                        ),
                                        'default' => 'after_add_to_cart',
                                        'dependency' => array('enable_comparison', '==', true),
                                    ),
                                ),
                            ),

                        ),
                    ),

                    // ==================== PRODUCT DESCRIPTION SETTINGS ====================
                    array(
                        'title' => __('Product Description', 'productbaseglut'),
                        'icon' => 'fas fa-file-alt',
                        'fields' => array(

                            // Description Section Layout
                            array(
                                'id' => 'product_description_section_settings',
                                'type' => 'fieldset',
                                'title' => __('Description Section Layout', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'show_description_section',
                                        'type' => 'switcher',
                                        'title' => __('Show Description Section', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'description_section_padding',
                                        'type' => 'slider',
                                        'title' => __('Section Padding', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 80,
                                        'step' => 5,
                                        'default' => 40,
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                    array(
                                        'id' => 'description_section_background',
                                        'type' => 'color',
                                        'title' => __('Section Background Color', 'productbaseglut'),
                                        'default' => '#ffffff',
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                    array(
                                        'id' => 'description_section_border_radius',
                                        'type' => 'slider',
                                        'title' => __('Section Border Radius', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 20,
                                        'step' => 1,
                                        'default' => 0,
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                ),
                            ),

                            // Description Title Styling
                            array(
                                'id' => 'description_title_settings',
                                'type' => 'fieldset',
                                'title' => __('Description Title', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'description_title_text',
                                        'type' => 'text',
                                        'title' => __('Title Text', 'productbaseglut'),
                                        'default' => __('Product Description', 'productbaseglut'),
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                    array(
                                        'id' => 'description_title_color',
                                        'type' => 'color',
                                        'title' => __('Title Color', 'productbaseglut'),
                                        'default' => '#111827',
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                    array(
                                        'id' => 'description_title_font_size',
                                        'type' => 'slider',
                                        'title' => __('Title Font Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 18,
                                        'max' => 40,
                                        'step' => 1,
                                        'default' => 28,
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                    array(
                                        'id' => 'description_title_font_weight',
                                        'type' => 'select',
                                        'title' => __('Title Font Weight', 'productbaseglut'),
                                        'options' => array(
                                            '400' => __('Normal', 'productbaseglut'),
                                            '500' => __('Medium', 'productbaseglut'),
                                            '600' => __('Semi Bold', 'productbaseglut'),
                                            '700' => __('Bold', 'productbaseglut'),
                                        ),
                                        'default' => '700',
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                    array(
                                        'id' => 'description_title_margin_bottom',
                                        'type' => 'slider',
                                        'title' => __('Title Bottom Margin', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 40,
                                        'step' => 2,
                                        'default' => 20,
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                ),
                            ),

                            // Description Content Styling
                            array(
                                'id' => 'description_content_settings',
                                'type' => 'fieldset',
                                'title' => __('Description Content', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'description_content_color',
                                        'type' => 'color',
                                        'title' => __('Content Text Color', 'productbaseglut'),
                                        'default' => '#4b5563',
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                    array(
                                        'id' => 'description_content_font_size',
                                        'type' => 'slider',
                                        'title' => __('Content Font Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 12,
                                        'max' => 20,
                                        'step' => 1,
                                        'default' => 16,
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                    array(
                                        'id' => 'description_content_line_height',
                                        'type' => 'slider',
                                        'title' => __('Content Line Height', 'productbaseglut'),
                                        'unit' => '',
                                        'min' => 1.2,
                                        'max' => 2.2,
                                        'step' => 0.1,
                                        'default' => 1.7,
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                    array(
                                        'id' => 'description_heading_color',
                                        'type' => 'color',
                                        'title' => __('Heading Color (h3, h4)', 'productbaseglut'),
                                        'default' => '#1f2937',
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                    array(
                                        'id' => 'description_heading_font_size',
                                        'type' => 'slider',
                                        'title' => __('Heading Font Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 16,
                                        'max' => 28,
                                        'step' => 1,
                                        'default' => 20,
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                    array(
                                        'id' => 'description_list_style',
                                        'type' => 'select',
                                        'title' => __('List Style', 'productbaseglut'),
                                        'options' => array(
                                            'disc' => __('Bullet Points (disc)', 'productbaseglut'),
                                            'circle' => __('Circle (circle)', 'productbaseglut'),
                                            'square' => __('Square (square)', 'productbaseglut'),
                                            'decimal' => __('Numbers (decimal)', 'productbaseglut'),
                                            'none' => __('None', 'productbaseglut'),
                                        ),
                                        'default' => 'disc',
                                        'dependency' => array('show_description_section', '==', true),
                                    ),
                                ),
                            ),
                        ),
                    ),

                    // ==================== PRODUCT REVIEWS SETTINGS ====================
                    array(
                        'title' => __('Product Reviews', 'productbaseglut'),
                        'icon' => 'fas fa-star',
                        'fields' => array(

                            // Reviews Section Layout
                            array(
                                'id' => 'reviews_section_settings',
                                'type' => 'fieldset',
                                'title' => __('Reviews Section Layout', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'show_reviews_section',
                                        'type' => 'switcher',
                                        'title' => __('Show Reviews Section', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'reviews_section_padding',
                                        'type' => 'slider',
                                        'title' => __('Section Padding', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 80,
                                        'step' => 5,
                                        'default' => 40,
                                        'dependency' => array('show_reviews_section', '==', true),
                                    ),
                                    array(
                                        'id' => 'reviews_section_background',
                                        'type' => 'color',
                                        'title' => __('Section Background Color', 'productbaseglut'),
                                        'default' => '#ffffff',
                                        'dependency' => array('show_reviews_section', '==', true),
                                    ),
                                    array(
                                        'id' => 'reviews_section_border_radius',
                                        'type' => 'slider',
                                        'title' => __('Section Border Radius', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 20,
                                        'step' => 1,
                                        'default' => 0,
                                        'dependency' => array('show_reviews_section', '==', true),
                                    ),
                                ),
                            ),

                            // Reviews Header Styling
                            array(
                                'id' => 'reviews_header_settings',
                                'type' => 'fieldset',
                                'title' => __('Reviews Header', 'productbaseglut'),
                                'dependency' => array('show_reviews_section', '==', true, true),
                                'fields' => array(
                                    array(
                                        'id' => 'reviews_header_text',
                                        'type' => 'text',
                                        'title' => __('Header Text', 'productbaseglut'),
                                        'default' => __('Customer Reviews', 'productbaseglut'),
                                    ),
                                    array(
                                        'id' => 'reviews_header_color',
                                        'type' => 'color',
                                        'title' => __('Header Color', 'productbaseglut'),
                                        'default' => '#111827',
                                    ),
                                    array(
                                        'id' => 'reviews_header_font_size',
                                        'type' => 'slider',
                                        'title' => __('Header Font Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 18,
                                        'max' => 40,
                                        'step' => 1,
                                        'default' => 28,
                                    ),
                                    array(
                                        'id' => 'reviews_header_font_weight',
                                        'type' => 'select',
                                        'title' => __('Header Font Weight', 'productbaseglut'),
                                        'options' => array(
                                            '400' => __('Normal', 'productbaseglut'),
                                            '500' => __('Medium', 'productbaseglut'),
                                            '600' => __('Semi Bold', 'productbaseglut'),
                                            '700' => __('Bold', 'productbaseglut'),
                                        ),
                                        'default' => '700',
                                    ),
                                    array(
                                        'id' => 'reviews_header_margin_bottom',
                                        'type' => 'slider',
                                        'title' => __('Header Bottom Margin', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 40,
                                        'step' => 2,
                                        'default' => 24,
                                    ),
                                ),
                            ),

                            // Review Card Styling
                            array(
                                'id' => 'review_card_settings',
                                'type' => 'fieldset',
                                'title' => __('Review Cards', 'productbaseglut'),
                                'dependency' => array('show_reviews_section', '==', true, true),
                                'fields' => array(
                                    array(
                                        'id' => 'review_card_background',
                                        'type' => 'color',
                                        'title' => __('Card Background', 'productbaseglut'),
                                        'default' => '#f9fafb',
                                    ),
                                    array(
                                        'id' => 'review_card_border_radius',
                                        'type' => 'slider',
                                        'title' => __('Card Border Radius', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 20,
                                        'step' => 1,
                                        'default' => 12,
                                    ),
                                    array(
                                        'id' => 'review_card_padding',
                                        'type' => 'slider',
                                        'title' => __('Card Padding', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 10,
                                        'max' => 40,
                                        'step' => 2,
                                        'default' => 20,
                                    ),
                                    array(
                                        'id' => 'review_card_margin_bottom',
                                        'type' => 'slider',
                                        'title' => __('Card Bottom Margin', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 40,
                                        'step' => 2,
                                        'default' => 16,
                                    ),
                                ),
                            ),

                            // Reviewer Info Styling
                            array(
                                'id' => 'reviewer_info_settings',
                                'type' => 'fieldset',
                                'title' => __('Reviewer Information', 'productbaseglut'),
                                'dependency' => array('show_reviews_section', '==', true, true),
                                'fields' => array(
                                    array(
                                        'id' => 'reviewer_avatar_background',
                                        'type' => 'color',
                                        'title' => __('Avatar Background', 'productbaseglut'),
                                        'default' => '#667eea',
                                    ),
                                    array(
                                        'id' => 'reviewer_avatar_text_color',
                                        'type' => 'color',
                                        'title' => __('Avatar Text Color', 'productbaseglut'),
                                        'default' => '#ffffff',
                                    ),
                                    array(
                                        'id' => 'reviewer_name_color',
                                        'type' => 'color',
                                        'title' => __('Reviewer Name Color', 'productbaseglut'),
                                        'default' => '#111827',
                                    ),
                                    array(
                                        'id' => 'reviewer_name_font_weight',
                                        'type' => 'select',
                                        'title' => __('Reviewer Name Font Weight', 'productbaseglut'),
                                        'options' => array(
                                            '400' => __('Normal', 'productbaseglut'),
                                            '500' => __('Medium', 'productbaseglut'),
                                            '600' => __('Semi Bold', 'productbaseglut'),
                                            '700' => __('Bold', 'productbaseglut'),
                                        ),
                                        'default' => '600',
                                    ),
                                    array(
                                        'id' => 'review_date_color',
                                        'type' => 'color',
                                        'title' => __('Review Date Color', 'productbaseglut'),
                                        'default' => '#9ca3af',
                                    ),
                                    array(
                                        'id' => 'review_date_font_size',
                                        'type' => 'slider',
                                        'title' => __('Review Date Font Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 10,
                                        'max' => 16,
                                        'step' => 1,
                                        'default' => 12,
                                    ),
                                ),
                            ),

                            // Review Rating Stars
                            array(
                                'id' => 'review_rating_settings',
                                'type' => 'fieldset',
                                'title' => __('Review Rating Stars', 'productbaseglut'),
                                'dependency' => array('show_reviews_section', '==', true, true),
                                'fields' => array(
                                    array(
                                        'id' => 'review_star_color',
                                        'type' => 'color',
                                        'title' => __('Star Color', 'productbaseglut'),
                                        'default' => '#fbbf24',
                                    ),
                                    array(
                                        'id' => 'review_star_size',
                                        'type' => 'slider',
                                        'title' => __('Star Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 12,
                                        'max' => 24,
                                        'step' => 1,
                                        'default' => 16,
                                    ),
                                ),
                            ),

                            // Review Text Styling
                            array(
                                'id' => 'review_text_settings',
                                'type' => 'fieldset',
                                'title' => __('Review Text', 'productbaseglut'),
                                'dependency' => array('show_reviews_section', '==', true, true),
                                'fields' => array(
                                    array(
                                        'id' => 'review_text_color',
                                        'type' => 'color',
                                        'title' => __('Review Text Color', 'productbaseglut'),
                                        'default' => '#4b5563',
                                    ),
                                    array(
                                        'id' => 'review_text_font_size',
                                        'type' => 'slider',
                                        'title' => __('Review Text Font Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 12,
                                        'max' => 18,
                                        'step' => 1,
                                        'default' => 14,
                                    ),
                                    array(
                                        'id' => 'review_text_line_height',
                                        'type' => 'slider',
                                        'title' => __('Review Text Line Height', 'productbaseglut'),
                                        'unit' => '',
                                        'min' => 1.2,
                                        'max' => 2.0,
                                        'step' => 0.1,
                                        'default' => 1.6,
                                    ),
                                ),
                            ),

                            // Review Form Styling
                            array(
                                'id' => 'review_form_settings',
                                'type' => 'fieldset',
                                'title' => __('Review Form', 'productbaseglut'),
                                'dependency' => array('show_reviews_section', '==', true, true),
                                'fields' => array(
                                    array(
                                        'id' => 'show_review_form',
                                        'type' => 'switcher',
                                        'title' => __('Show Review Form', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'review_form_title',
                                        'type' => 'text',
                                        'title' => __('Form Title', 'productbaseglut'),
                                        'default' => __('Write Your Review', 'productbaseglut'),
                                        'dependency' => array('show_review_form', '==', true),
                                    ),
                                    array(
                                        'id' => 'review_form_title_color',
                                        'type' => 'color',
                                        'title' => __('Form Title Color', 'productbaseglut'),
                                        'default' => '#111827',
                                        'dependency' => array('show_review_form', '==', true),
                                    ),
                                    array(
                                        'id' => 'review_form_title_font_size',
                                        'type' => 'slider',
                                        'title' => __('Form Title Font Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 16,
                                        'max' => 32,
                                        'step' => 1,
                                        'default' => 22,
                                        'dependency' => array('show_review_form', '==', true),
                                    ),
                                    array(
                                        'id' => 'review_form_background',
                                        'type' => 'color',
                                        'title' => __('Form Background', 'productbaseglut'),
                                        'default' => '#f9fafb',
                                        'dependency' => array('show_review_form', '==', true),
                                    ),
                                    array(
                                        'id' => 'review_form_border_radius',
                                        'type' => 'slider',
                                        'title' => __('Form Border Radius', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 20,
                                        'step' => 1,
                                        'default' => 12,
                                        'dependency' => array('show_review_form', '==', true),
                                    ),
                                    array(
                                        'id' => 'review_form_padding',
                                        'type' => 'slider',
                                        'title' => __('Form Padding', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 10,
                                        'max' => 40,
                                        'step' => 2,
                                        'default' => 24,
                                        'dependency' => array('show_review_form', '==', true),
                                    ),
                                    array(
                                        'id' => 'review_form_label_color',
                                        'type' => 'color',
                                        'title' => __('Form Label Color', 'productbaseglut'),
                                        'default' => '#374151',
                                        'dependency' => array('show_review_form', '==', true),
                                    ),
                                    array(
                                        'id' => 'review_form_input_background',
                                        'type' => 'color',
                                        'title' => __('Form Input Background', 'productbaseglut'),
                                        'default' => '#ffffff',
                                        'dependency' => array('show_review_form', '==', true),
                                    ),
                                    array(
                                        'id' => 'review_form_input_border_color',
                                        'type' => 'color',
                                        'title' => __('Form Input Border Color', 'productbaseglut'),
                                        'default' => '#d1d5db',
                                        'dependency' => array('show_review_form', '==', true),
                                    ),
                                    array(
                                        'id' => 'review_form_input_border_radius',
                                        'type' => 'slider',
                                        'title' => __('Form Input Border Radius', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 15,
                                        'step' => 1,
                                        'default' => 6,
                                        'dependency' => array('show_review_form', '==', true),
                                    ),
                                    array(
                                        'id' => 'submit_button_background',
                                        'type' => 'color',
                                        'title' => __('Submit Button Background', 'productbaseglut'),
                                        'default' => '#667eea',
                                        'dependency' => array('show_review_form', '==', true),
                                    ),
                                    array(
                                        'id' => 'submit_button_text_color',
                                        'type' => 'color',
                                        'title' => __('Submit Button Text Color', 'productbaseglut'),
                                        'default' => '#ffffff',
                                        'dependency' => array('show_review_form', '==', true),
                                    ),
                                    array(
                                        'id' => 'submit_button_border_radius',
                                        'type' => 'slider',
                                        'title' => __('Submit Button Border Radius', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 0,
                                        'max' => 20,
                                        'step' => 1,
                                        'default' => 6,
                                        'dependency' => array('show_review_form', '==', true),
                                    ),
                                ),
                            ),
                        ),
                    ),

                    // ==================== SOCIAL SHARE SETTINGS ====================
                    array(
                        'title' => __('Social Share', 'productbaseglut'),
                        'icon' => 'fas fa-share-alt',
                        'fields' => array(

                            // Social Share Settings
                            array(
                                'id' => 'social_share_settings',
                                'type' => 'fieldset',
                                'title' => __('Social Share Settings', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'enable_social_share',
                                        'type' => 'switcher',
                                        'title' => __('Enable Social Share', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'social_share_label',
                                        'type' => 'text',
                                        'title' => __('Social Share Label', 'productbaseglut'),
                                        'default' => 'Share:',
                                        'dependency' => array('enable_social_share', '==', true),
                                    ),
                                    array(
                                        'id' => 'social_share_icons',
                                        'type' => 'repeater',
                                        'title' => __('Social Icons', 'productbaseglut'),
                                        'button_label' => __('Add Social Icon', 'productbaseglut'),
                                        'dependency' => array('enable_social_share', '==', true),
                                        'fields' => array(
                                            array(
                                                'id' => 'social_icon',
                                                'type' => 'text',
                                                'title' => __('Icon Class', 'productbaseglut'),
                                                'default' => 'fab fa-facebook-f',
                                            ),
                                            array(
                                                'id' => 'social_background',
                                                'type' => 'color',
                                                'title' => __('Background Color', 'productbaseglut'),
                                                'default' => '#1877f2',
                                            ),
                                            array(
                                                'id' => 'social_color',
                                                'type' => 'color',
                                                'title' => __('Icon Color', 'productbaseglut'),
                                                'default' => '#ffffff',
                                            ),
                                            array(
                                                'id' => 'social_hover_background',
                                                'type' => 'color',
                                                'title' => __('Hover Background Color', 'productbaseglut'),
                                                'default' => '#0e5f9e',
                                            ),
                                            array(
                                                'id' => 'social_hover_color',
                                                'type' => 'color',
                                                'title' => __('Hover Icon Color', 'productbaseglut'),
                                                'default' => '#ffffff',
                                            ),
                                            array(
                                                'id' => 'social_border_radius',
                                                'type' => 'slider',
                                                'title' => __('Border Radius', 'productbaseglut'),
                                                'unit' => 'px',
                                                'min' => 0,
                                                'max' => 20,
                                                'step' => 1,
                                                'default' => 6,
                                            ),
                                        ),
                                    ),
                                    array(
                                        'id' => 'social_icon_size',
                                        'type' => 'slider',
                                        'title' => __('Icon Size', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 30,
                                        'max' => 50,
                                        'step' => 2,
                                        'default' => 40,
                                        'dependency' => array('enable_social_share', '==', true),
                                    ),
                                    array(
                                        'id' => 'social_icon_spacing',
                                        'type' => 'slider',
                                        'title' => __('Icon Spacing', 'productbaseglut'),
                                        'unit' => 'px',
                                        'min' => 4,
                                        'max' => 20,
                                        'step' => 2,
                                        'default' => 10,
                                        'dependency' => array('enable_social_share', '==', true),
                                    ),
                                ),
                            ),
                        ),
                    ),

                    // ==================== DEMO SECTION VISIBILITY SETTINGS ====================
                    array(
                        'title' => __('Demo Section Visibility', 'productbaseglut'),
                        'icon' => 'fas fa-eye',
                        'fields' => array(

                            // Product Elements Visibility
                            array(
                                'id' => 'demo_visibility_settings',
                                'type' => 'fieldset',
                                'title' => __('Product Elements Visibility', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'show_demo_badges',
                                        'type' => 'switcher',
                                        'title' => __('Show Product Badges', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'show_demo_title',
                                        'type' => 'switcher',
                                        'title' => __('Show Product Title', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'show_demo_rating',
                                        'type' => 'switcher',
                                        'title' => __('Show Rating Stars', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'show_demo_price',
                                        'type' => 'switcher',
                                        'title' => __('Show Price Section', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'show_demo_description',
                                        'type' => 'switcher',
                                        'title' => __('Show Short Description', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'show_demo_variations',
                                        'type' => 'switcher',
                                        'title' => __('Show Product Variations (Color/Size)', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'show_demo_cart_section',
                                        'type' => 'switcher',
                                        'title' => __('Show Cart Section (Quantity, Add to Cart)', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'show_demo_action_buttons',
                                        'type' => 'switcher',
                                        'title' => __('Show Action Buttons (Wishlist, Compare)', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'show_demo_social_share',
                                        'type' => 'switcher',
                                        'title' => __('Show Social Share Icons', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                ),
                            ),

                            // Section Visibility
                            array(
                                'id' => 'demo_section_visibility',
                                'type' => 'fieldset',
                                'title' => __('Section Visibility', 'productbaseglut'),
                                'fields' => array(
                                    array(
                                        'id' => 'show_demo_description_section',
                                        'type' => 'switcher',
                                        'title' => __('Show Product Description Section', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                    array(
                                        'id' => 'show_demo_reviews_section',
                                        'type' => 'switcher',
                                        'title' => __('Show Reviews Section', 'productbaseglut'),
                                        'default' => true,
                                    ),
                                ),
                            ),
                        ),
                    ),

                ),
            ),
        );



// Create the section with all fields
AGSHOPGLUT::createSection(
    $SHOPG_singleproduct_STYLING,
    array(
        'fields' => $all_fields1
    )
);
?>