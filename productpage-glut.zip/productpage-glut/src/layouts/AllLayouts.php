<?php
namespace Productpageglut\layouts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


use Productpageglut\layouts\productPage\chooseTemplates as SingleProductTemplates;
use Productpageglut\layouts\productPage\ProductPageListTable;
use Productpageglut\layouts\productPage\ProductLayoutEntity;
use Productpageglut\layouts\productPage\SettingsPage as SingleProductEditor;



class AllLayouts {

	public $not_implemented;

	public function __construct() {


		add_filter( 'admin_body_class', array( $this, 'shopglutBodyClass' ) );

        $this->not_implemented = true;


	}


	public function shopglutBodyClass( $classes ) {
		$current_screen = get_current_screen();

		if ( empty( $current_screen ) ) {
			return $classes;
		}
		if ( false !== strpos( $current_screen->id, 'productpageglut_' ) ) {
			$classes .= ' shopglut-admin shopglut-admin';
		}

		if ( false !== strpos( $current_screen->id, 'productpageglut_' ) ) {
			$classes .= ' productpageglut-admin productpageglut-admin';
		}


		// Only apply editor-specific classes in admin context with proper permissions
		if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
			return $classes;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Safe admin page parameter check for body class only
		if ( isset( $_GET['page'] ) && 'productpageglut_layouts' === sanitize_text_field( wp_unslash( $_GET['page'] ) ) && isset( $_GET['editor'] ) ) {
			$classes .= '-productpageglut-shop-editor ';
		}

		// PHPCS: Input var ok. Body class filter context doesn't require nonce verification.
		if ( isset( $_GET['page'] ) && 'productpageglut_layouts' === sanitize_text_field( wp_unslash( $_GET['page'] ) ) && isset( $_GET['editor'] ) && 'product_page' === sanitize_text_field( wp_unslash( $_GET['editor'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$classes .= '-sg-single-product ';
		}

		return $classes;
	}

	public function renderLayoutsPages() {

		$singleProduct_editor = new SingleProductEditor();

		// Sanitize and validate input - only in admin context
		$page = '';
		$editor = '';
		$layout_id = 0;
		$view = '';

		if ( is_admin() && current_user_can( 'manage_options' ) ) {
			// Verify nonce if present (for editor actions), skip for basic navigation
			$nonce_verified = true;
			if ( isset( $_GET['_wpnonce'] ) && isset( $_GET['action'] ) && $_GET['action'] === 'delete' && isset( $_GET['layout_id'] ) ) {
				// For delete actions, verify against the specific delete nonce
				$delete_layout_id = absint( $_GET['layout_id'] );
				$nonce_verified = wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'shopglut_delete_layout_' . $delete_layout_id );
			} elseif ( isset( $_GET['_wpnonce'] ) ) {
				// For other actions, verify against the general admin action nonce
				$nonce_verified = wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'shopglut_admin_action' );
			}

			if ( $nonce_verified ) {
				$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
				$editor = isset( $_GET['editor'] ) ? sanitize_text_field( wp_unslash( $_GET['editor'] ) ) : '';
				$layout_id = isset( $_GET['layout_id'] ) ? absint( $_GET['layout_id'] ) : 0;
				$view = isset( $_GET['view'] ) ? sanitize_text_field( wp_unslash( $_GET['view'] ) ) : '';
			}
		}


		if ( 'productpageglut_layouts' === $page && 'product_page' === $editor && $layout_id > 0 ) {
			$singleProduct_editor->loadSingleProductEditor();
		} elseif ( 'productpageglut_layouts' === $page && 'single_product_templates' === $view ) {
			$this->SingleProductlayoutTemplatesPage();
		} elseif ( 'productpageglut_layouts' === $page && ! empty( $view ) ) {
			switch ( $view ) {
				case 'product_page':
					$this->renderSingleProduct();
					break;
				default:
					//$this->renderLayoutsTable();
					break;
			}
		} elseif ( 'productpageglut_layouts' === $page ) {
			$this->renderWooCommerceLayouts();
		} else {
			wp_die( esc_html__( 'Sorry, you are not allowed to access this page.', 'productpageglut' ) );
		}

	}


	public function settingsPageHeader( $active_menu ) {
		$logo_url = PRODUCTPAGEGLUT_URL . 'global-assets/images/header-logo.svg';
		?>
		<div class="productpageglut-page-header">
			<div class="productpageglut-page-header-wrap">
				<div class="productpageglut-page-header-banner productpageglut-pro productpageglut-no-submenu">
					<div class="productpageglut-page-header-banner__logo">
						<img src="<?php echo esc_url( $logo_url ); ?>" alt="">
					</div>
					<div class="productpageglut-page-header-banner__helplinks">
						<span><a rel="noopener"
								href="https://productpageglut.appglut.com/?utm_source=shoglutplugin-admin&utm_medium=referral&utm_campaign=adminmenu"
								target="_blank">
								<span class="dashicons dashicons-admin-page"></span>
								<?php echo esc_html__( 'Documentation', 'productpageglut' ); ?>
							</a></span>
						<span><a class="productpageglut-active" rel="noopener"
								href="https://www.appglut.com/plugin/productpageglut/?utm_source=shoglutplugin-admin&utm_medium=referral&utm_campaign=upgrade"
								target="_blank">
								<span class="dashicons dashicons-unlock"></span>
								<?php echo esc_html__( 'Unlock Pro Edition', 'productpageglut' ); ?>
							</a></span>
						<span><a rel="noopener"
								href="https://www.appglut.com/support/?utm_source=shoglutplugin-admin&utm_medium=referral&utm_campaign=support"
								target="_blank">
								<span class="dashicons dashicons-share-alt"></span>
								<?php echo esc_html__( 'Support', 'productpageglut' ); ?>
							</a></span>
					</div>
					<div class="clear"></div>
					<?php $this->settingsPageHeaderMenus( $active_menu ); ?>
				</div>
			</div>
		</div>
		<?php
	}

	public function settingsPageHeaderMenus( $active_menu ) {

		$menus = $this->headerMenuTabs();

		?>
		<div class="productpageglut-header-menus">
			<nav class="productpageglut-nav-tab-wrapper nav-tab-wrapper">
				<?php foreach ( $menus as $menu ) : ?>
					<?php $id = $menu['id'];
					$url = esc_url_raw( ! empty( $menu['url'] ) ? $menu['url'] : '' );
					?>
					<a href="<?php echo esc_url( remove_query_arg( wp_removable_query_args(), $url ) ); ?>"
						class="productpageglut-nav-tab nav-tab<?php echo esc_attr( $id ) == esc_attr( $active_menu ) ? ' productpageglut-nav-active' : ''; ?>">
						<?php echo esc_html( $menu['label'] ); ?>
					</a>
				<?php endforeach; ?>
			</nav>
		</div>
		<?php
	}

	public function defaultHeaderMenu() {
		return 'product_page';
	}

	public function headerMenuTabs() {
		$tabs = [
			1 => [ 'id' => 'product_page', 'url' => admin_url( 'admin.php?page=productpageglut_layouts&view=product_page' ), 'label' => '📦 ' . esc_html__( 'Product Page Layouts', 'productpageglut' ) ],
		];

		ksort( $tabs );

		return $tabs;
}

	public function activeMenuTab() {
		// PHPCS: Input var ok. Navigation context doesn't require nonce verification.
		$page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		// PHPCS: Input var ok. Navigation context doesn't require nonce verification.
		$view = isset( $_GET['view'] ) ? sanitize_text_field( wp_unslash( $_GET['view'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		// Check if we're on productpageglut layouts page
		if ( 'productpageglut_layouts' === $page ) {
			// If no view parameter, default to product_page
			if ( empty( $view ) ) {
				return 'product_page';
			}
			return $view;
		}

		return false;
	}

	public function SingleProductlayoutTemplatesPage() {
		$active_menu = 'product_page';
		$this->settingsPageHeader( $active_menu );
		$shopLayout_templates = new SingleProductTemplates();
		?>
		<div class="wrap productpageglut-admin-contents shoplayouts-templates">
			<h1><?php echo esc_html__( 'Prebuilt SingleProduct Templates', 'productpageglut' ); ?></h1>
			<p class="subheading"><?php echo esc_html__( 'Choose your desired template to customize', 'productpageglut' ); ?></p>
			<?php $shopLayout_templates->loadSingleProductTemplates(); ?>
		</div>
		<?php
	}

	public function renderSingleProduct() {
		 //if($this->not_implemented):
		 //$this->renderNotImplementedMessage();
		 //else: ?>
		<?php
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'productpageglut' ) );
		}

		// Check if product_page module is enabled
		// $module_manager = \Productpageglut\ModuleManager::get_instance();
		// if ( ! $module_manager->is_module_enabled( 'product_page' ) ) {
		// 	$active_menu = $this->activeMenuTab();
		// 	$this->settingsPageHeader( $active_menu );
		// 	$module_manager->render_disabled_module_message( 'product_page' );
		// 	return;
		// }

		// Handle individual delete action FIRST - before any other actions
		if ( isset( $_GET['action'] ) && $_GET['action'] === 'delete' && isset( $_GET['layout_id'] ) ) {
			$layout_id = absint( $_GET['layout_id'] );

			// Verify nonce
			if ( isset( $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'shopglut_delete_layout_' . $layout_id ) ) {
				// Delete the layout
				\Productpageglut\layouts\productPage\ProductLayoutEntity::delete_layout( $layout_id );

				// Redirect to avoid resubmission
				wp_safe_redirect( admin_url( 'admin.php?page=productpageglut_layouts&view=product_page&deleted=true' ) );
				exit;
			} else {
				wp_die( esc_html__( 'Security check failed.', 'productpageglut' ) );
			}
		}

		// Handle direct creation from "Create From New" button
		if ( isset( $_GET['action'] ) && $_GET['action'] === 'create_new' && isset( $_GET['_wpnonce'] ) ) {
			if ( wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'create_new_layout_nonce' ) ) {
				try {
					// Get next layout ID
					global $wpdb;
					$table_name = $wpdb->prefix . 'shopglut_single_product_layout';
					$layout_id = intval($wpdb->get_var("SELECT MAX(id) FROM {$wpdb->prefix}shopglut_single_product_layout")) + 1 ?: 1;			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table existence check with caching, safe table name from internal function

					// Create layout directly with default settings
					$current_time = current_time('mysql');
					$data = array(
						'id' => $layout_id,
						'layout_name' => sanitize_text_field('Layout(#' . $layout_id . ')'),
						'layout_template' => 'template_default', // Default template
						'layout_settings' => '{}', // Default empty JSON object
						'created_at' => $current_time,
						'updated_at' => $current_time
					);

					$format = array('%d', '%s', '%s', '%s', '%s', '%s');


					$inserted = $wpdb->insert($table_name, $data, $format);			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table existence check with caching, safe table name from internal function


					if ($inserted !== false) {
						// Redirect to editor on success
						$redirect_url = add_query_arg(
							array(
								'page' => 'productpageglut_layouts',
								'editor' => 'product_page',
								'layout_id' => $layout_id
							),
							admin_url('admin.php')
						);
						wp_safe_redirect($redirect_url);
						exit;
					} else {
						// Handle database insertion failure
						add_action('admin_notices', function() {
							echo '<div class="error notice"><p>' . esc_html__('Failed to create new layout. Please try again.', 'productpageglut') . '</p></div>';
						});
					}
				} catch (Exception $e) {
					// Handle any exceptions
					add_action('admin_notices', function() use ($e) {
						echo '<div class="error notice"><p>' . esc_html__('An error occurred: ', 'productpageglut') . esc_html($e->getMessage()) . '</p></div>';
					});
				}
			} else {
				// Handle nonce verification failure
				wp_die( esc_html__( 'Security check failed.', 'productpageglut' ) );
			}
		}


		// Show success/error messages
		if ( isset( $_GET['deleted'] ) && $_GET['deleted'] === 'true' ) {
			echo '<div class="updated notice"><p>' . esc_html__( 'Layout deleted successfully.', 'productpageglut' ) . '</p></div>';
		}
		// Show bulk delete success message
		if ( isset( $_GET['deleted'] ) && $_GET['deleted'] === 'bulk' && isset( $_GET['count'] ) ) {
			$count = absint( $_GET['count'] );
			if ( $count > 0 ) {
				printf(
					'<div class="updated notice"><p>%s</p></div>',
					esc_html( sprintf(
						_n(
							'%d layout deleted successfully.',
							'%d layouts deleted successfully.',
							$count,
							'productpageglut'
						),
						$count
					) )
				);
			}
		}

		// Handle bulk delete action (check POST before any output)
		if ( isset( $_POST['action'] ) && $_POST['action'] === 'delete' && isset( $_POST['user'] ) ) {
			check_admin_referer( 'bulk-layouts' );

			$layout_ids = array_map( 'absint', wp_unslash( $_POST['user'] ) );

			if ( ! empty( $layout_ids ) ) {
				$deleted_count = 0;
				foreach ( $layout_ids as $layout_id ) {
					$result = \Productpageglut\layouts\productPage\ProductLayoutEntity::delete_layout( $layout_id );
					if ( $result !== false ) {
						$deleted_count++;
					}
				}

				// Redirect to avoid resubmission and show success message
				$redirect_url = add_query_arg(
					array(
						'page' => 'productpageglut_layouts',
						'view' => 'product_page',
						'deleted' => 'bulk',
						'count' => $deleted_count
					),
					admin_url( 'admin.php' )
				);
				wp_safe_redirect( $redirect_url );
				exit;
			}
		}

		// Handle bulk delete from bottom dropdown
		if ( isset( $_POST['action2'] ) && $_POST['action2'] === 'delete' && isset( $_POST['user'] ) ) {
			check_admin_referer( 'bulk-layouts' );

			$layout_ids = array_map( 'absint', wp_unslash( $_POST['user'] ) );

			if ( ! empty( $layout_ids ) ) {
				$deleted_count = 0;
				foreach ( $layout_ids as $layout_id ) {
					$result = \Productpageglut\layouts\productPage\ProductLayoutEntity::delete_layout( $layout_id );
					if ( $result !== false ) {
						$deleted_count++;
					}
				}

				// Redirect to avoid resubmission and show success message
				$redirect_url = add_query_arg(
					array(
						'page' => 'productpageglut_layouts',
						'view' => 'product_page',
						'deleted' => 'bulk',
						'count' => $deleted_count
					),
					admin_url( 'admin.php' )
				);
				wp_safe_redirect( $redirect_url );
				exit;
			}
		}

		// Prepare layouts table
		$layouts_table = new ProductPageListTable();
		$layouts_table->prepare_items();
		$active_menu = $this->activeMenuTab();
		$this->settingsPageHeader( $active_menu );

		// Generate URLs for the action buttons
		$templates_url = admin_url( 'admin.php?page=productpageglut_layouts&view=single_product_templates' );

		$create_new_url = add_query_arg(
			array(
				'page' => 'productpageglut_layouts',
				'view' => 'product_page',
				'action' => 'create_new',
				'_wpnonce' => wp_create_nonce('create_new_layout_nonce')
			),
			admin_url('admin.php')
		);
		?>
		<div class="wrap productpageglut-admin-contents">
			<h2><?php echo esc_html__( 'Product Page Layouts', 'productpageglut' ); ?>
				<a href="<?php echo esc_url( $templates_url ); ?>">
					<span class="add-new-h2"><?php echo esc_html__( 'Create From Templates', 'productpageglut' ); ?></span>
				</a>

				<!-- <a href="<?php echo esc_url( $create_new_url ); ?>">
					<span class="add-new-h2"><?php echo esc_html__( 'Create From New', 'productpageglut' ); ?></span>
				</a> -->
			</h2>

			<form method="post" id="productpageglut-layouts-form">
				<?php $layouts_table->display(); ?>
			</form>
		</div>
		<?php //endif; ?>
		<?php
  }

	public function renderWooCommerceLayouts() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'productpageglut' ) );
		}

		$active_menu = $this->activeMenuTab();
		$this->settingsPageHeader( $active_menu );
		?>
		<div class="wrap productpageglut-admin-contents">
			<h2 style="text-align: center; font-weight: bold;"><?php echo esc_html__( 'WooCommerce Layouts', 'productpageglut' ); ?></h2>
			<p class="subheading" style="text-align: center;">
				<?php echo esc_html__( 'Design and customize your WooCommerce store pages with our powerful layout builder', 'productpageglut' ); ?>
			</p>
			<div class="productpageglut-enhancements-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 30px;">

				<!-- Product Page -->
				<div class="productpageglut-option-card" style="background: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
					<div class="option-header" style="display: flex; align-items: center; margin-bottom: 15px;">
						<i class="fas fa-cube" style="font-size: 24px; color: #667eea; margin-right: 12px;"></i>
						<h3 style="margin: 0; color: #333;"><?php echo esc_html__( 'Product Page', 'productpageglut' ); ?></h3>
					</div>
					<p style="color: #666; margin-bottom: 15px;"><?php echo esc_html__( 'Create stunning product detail pages with custom layouts and elements.', 'productpageglut' ); ?></p>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=productpageglut_layouts&view=product_page' ) ); ?>" class="button button-primary"><?php echo esc_html__( 'Manage Layouts', 'productpageglut' ); ?></a>
				</div>

			</div>
		</div>
		<?php
	}

	public static function get_instance() {
		static $instance;

		if ( is_null( $instance ) ) {
			$instance = new self();
		}
		return $instance;
	}
}
