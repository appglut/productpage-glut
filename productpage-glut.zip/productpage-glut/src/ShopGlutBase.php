<?php
namespace Productbaseglut;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Productbaseglut\layouts\AllLayouts;
use Productbaseglut\layouts\singleProduct\chooseTemplates as SingleProductTemplates;
use Productbaseglut\layouts\singleProduct\dataManage as SingleProductDataManage;


class ShopGlutBase {

	// Declare properties to fix PHP 8.2+ deprecation warnings
	public $menu_slug;

	public function __construct() {

		// Initialize core components
		ShopGlutDatabase::ShopGlut_initialize();
		ShopGlutDatabase::force_create_core_tables(); // Ensure core tables exist even if modules are disabled
		ShopGlutRegisterScripts::get_instance();
		ShopGlutRegisterMenu::get_instance();
		AllLayouts::get_instance();
		

		SingleProductDataManage::get_instance();
		SingleProductTemplates::get_instance();

		


		// Add actions
		add_action( 'init', array( $this, 'shopglutInitialFunctions' ), 9 );
		add_filter( 'update_footer', array( $this, 'shopglut_admin_footer_version' ), 999 );

		// Hook the redirection function into admin_init
		add_action( 'admin_init', array( $this, 'shopglut_redirect_after_activation' ) );
	}

	public function shopglut_redirect_after_activation() {
		if ( ! get_option( 'shopglut_plugin_first_activation_redirect' ) ) {
			// Set the option to ensure this runs only once
			update_option( 'shopglut_plugin_first_activation_redirect', true );

			// Redirect to the welcome page after activation
			wp_safe_redirect( admin_url( 'admin.php?page=productbaseglut-welcome' ) );
			exit;
		}
	}

	public function shopglutInitialFunctions() {
		// Load required files
		require_once PRODUCTBASEGLUT_PATH . 'src/library/model/classes/setup.class.php';
		require_once PRODUCTBASEGLUT_PATH . 'src/layouts/singleProduct/singleLayout-settings.php';
	}

	public function shopglut_admin_footer_version() {
		return '<span id="productbaseglut-footer-version" style="display: none;">Productbaseglut ' . PRODUCTBASEGLUT_VERSION . '</span>';
	}

	public static function get_instance() {
		static $instance;

		if ( is_null( $instance ) ) {
			$instance = new self();
		}
		return $instance;
	}
}