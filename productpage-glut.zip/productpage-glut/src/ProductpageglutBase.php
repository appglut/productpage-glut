<?php
namespace Productpageglut;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Productpageglut\layouts\AllLayouts;
use Productpageglut\layouts\productPage\chooseTemplates as SingleProductTemplates;
use Productpageglut\layouts\productPage\dataManage as SingleProductDataManage;


class ProductpageglutBase {

	// Declare properties to fix PHP 8.2+ deprecation warnings
	public $menu_slug;

	public function __construct() {

		// Initialize core components
		ShopGlutDatabase::Productpageglut_initialize();
		ShopGlutDatabase::force_create_core_tables(); // Ensure core tables exist even if modules are disabled
		ShopGlutRegisterScripts::get_instance();
		ShopGlutRegisterMenu::get_instance();
		AllLayouts::get_instance();
		

		SingleProductDataManage::get_instance();
		SingleProductTemplates::get_instance();

		


		// Add actions
		add_action( 'init', array( $this, 'shopglutInitialFunctions' ), 9 );
		add_filter( 'update_footer', array( $this, 'productpageglut_admin_footer_version' ), 999 );

		// Hook the redirection function into admin_init
		add_action( 'admin_init', array( $this, 'productpageglut_redirect_after_activation' ) );
	}

	public function productpageglut_redirect_after_activation() {
		if ( ! get_option( 'productpageglut_plugin_first_activation_redirect' ) ) {
			// Set the option to ensure this runs only once
			update_option( 'productpageglut_plugin_first_activation_redirect', true );

			// Redirect to the welcome page after activation
			wp_safe_redirect( admin_url( 'admin.php?page=productpageglut-welcome' ) );
			exit;
		}
	}

	public function shopglutInitialFunctions() {

		// Load setup class from ShopGlut if active, otherwise from productpage-glut
		if (defined('SHOPGLUT_VERSION')) {
			require_once SHOPGLUT_PATH . 'src/library/model/classes/setup.class.php';
		} else {
			require_once PRODUCTPAGEGLUT_PATH . 'src/library/model/classes/setup.class.php';
		}
		require_once PRODUCTPAGEGLUT_PATH . 'src/layouts/productPage/productLayout-settings.php';
	}

	public function productpageglut_admin_footer_version() {
		return '<span id="productpageglut-footer-version" style="display: none;">Productpageglut ' . PRODUCTPAGEGLUT_VERSION . '</span>';
	}

	public static function get_instance() {
		static $instance;

		if ( is_null( $instance ) ) {
			$instance = new self();
		}
		return $instance;
	}
}