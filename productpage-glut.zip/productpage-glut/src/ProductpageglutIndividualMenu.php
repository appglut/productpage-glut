<?php
namespace Productpageglut;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class for managing ProductPageGlut individual top-level menu
 * This ensures the individual menu shows the same content as ProductPageGlut's layouts submenu
 */
class ProductpageglutIndividualMenu {

	/**
	 * Constructor
	 */
	public function __construct() {
		// Add menu using standard WordPress priority
		add_action( 'admin_menu', array( $this, 'addIndividualMenu' ), 20 );
		// Enqueue assets for the individual menu page
		add_action( 'load-toplevel_page_productbaseglut', array( $this, 'enqueueAssets' ) );
	}

	/**
	 * Add individual top-level menu when enabled from integration settings
	 */
	public function addIndividualMenu() {

		// Only add menu if enabled from integration settings
		if ( ! $this->showIndividualMenu() ) {
			return;
		}


		// Add top-level menu for ProductPageGlut
		add_menu_page(
			'ProductPageGlut',
			'ProductPageGlut',
			'manage_options',
			'productbaseglut',
			array( $this, 'renderPage' ),
			'dashicons-cart',
			30
		);

		// Add Welcome submenu
		add_submenu_page(
			'productbaseglut',
			esc_html__( 'Welcome', 'productbaseglut' ),
			esc_html__( 'Welcome', 'productbaseglut' ),
			'manage_options',
			'productbaseglut-welcome',
			array( $this, 'render_welcome_page' )
		);
	}

	/**
	 * Check if individual menu should be shown
	 *
	 * @return bool Whether to show the individual menu
	 */
	public function showIndividualMenu() {
		// Get integration settings
		$settings = get_option( 'shopglut_integration_settings', array() );


		// Check if the productpageglut-show-menu option is enabled
		if ( isset( $settings['productpageglut-show-menu'] ) ) {
			// AGSHOPGLUT framework stores '1' or '0' as string, check for both
			return $settings['productpageglut-show-menu'] === '1' || $settings['productpageglut-show-menu'] === true || $settings['productpageglut-show-menu'] === 1;
		}

		return false;
	}

	/**
	 * Render the page - loads the same content that ProductPageGlut uses
	 * Passes 'productbaseglut' as menu_slug to ensure URLs stay within individual menu
	 */
	public function renderPage() {
		// Load and render the layouts page
		if ( class_exists( 'Productbaseglut\\layouts\\AllLayouts' ) ) {
			$layouts = \Productbaseglut\layouts\AllLayouts::get_instance();
			$layouts->renderLayoutsPages();
			return;
		}

		// Fallback message if handler not found
		echo '<div class="wrap"><h1>' . esc_html__( 'ProductPageGlut Settings', 'productbaseglut' ) . '</h1>';
		echo '<p>' . esc_html__( 'Unable to load ProductPageGlut settings page.', 'productbaseglut' ) . '</p></div>';
	}

	/**
	 * Enqueue assets for the individual menu page
	 */
	public function enqueueAssets() {
		// Enqueue the same assets that ProductPageGlut uses
		do_action( 'admin_enqueue_scripts', 'toplevel_page_productbaseglut' );
	}

	/**
	 * Render welcome page
	 */
	public function render_welcome_page() {
		$welcome_page = new \Productbaseglut\WelcomePage();
		$welcome_page->render_welcome_content();
	}

	/**
	 * Get singleton instance
	 *
	 * @return ProductpageglutIndividualMenu
	 */
	public static function get_instance() {
		static $instance = null;

		if ( is_null( $instance ) ) {
			$instance = new self();
		}

		return $instance;
	}
}
