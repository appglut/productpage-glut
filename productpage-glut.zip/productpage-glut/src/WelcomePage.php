<?php
/**
 * Welcome Page for ProductPageGlut
 *
 * @package Productbaseglut
 */

namespace Productbaseglut;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WelcomePage {

	/**
	 * Render the welcome page content
	 */
	public function render_welcome_content() {
		// Check if user can access
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'productbaseglut' ) );
		}
		?>
		<div class="wrap pbg-wrap-full productbaseglut-welcome-page">
			<style>
				/* Hide default WP title and add custom header */
				.productbaseglut-welcome-page > h1 {
					display: none;
				}

				.pbg-welcome-wrapper {
					max-width: 1000px;
					margin: 20px auto;
					background: #ffffff;
					border-radius: 12px;
					box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
					overflow: hidden;
				}

				.pbg-welcome-header {
					background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
					padding: 50px 40px;
					text-align: center;
					color: #ffffff;
				}

				.pbg-welcome-logo {
					width: 100px;
					height: 100px;
					background: rgba(255, 255, 255, 0.2);
					border-radius: 24px;
					margin: 0 auto 20px;
					display: flex;
					align-items: center;
					justify-content: center;
				}

				.pbg-welcome-logo svg {
					width: 70px;
					height: 70px;
				}

				.pbg-welcome-header h1 {
					font-size: 36px;
					font-weight: 700;
					margin: 0 0 10px 0;
					letter-spacing: -0.5px;
					color: #ffffff;
					display: block !important;
				}

				.pbg-welcome-subtitle {
					font-size: 18px;
					opacity: 0.95;
					font-weight: 400;
				}

				.pbg-welcome-content {
					padding: 40px;
				}

				.pbg-welcome-thank-you {
					text-align: center;
					margin-bottom: 40px;
				}

				.pbg-welcome-thank-you h2 {
					font-size: 24px;
					color: #1d2327;
					margin: 0 0 12px 0;
					font-weight: 600;
				}

				.pbg-welcome-thank-you p {
					font-size: 15px;
					color: #475569;
					line-height: 1.6;
					max-width: 550px;
					margin: 0 auto;
				}

				.pbg-welcome-features {
					display: grid;
					grid-template-columns: repeat(3, 1fr);
					gap: 24px;
					margin-bottom: 40px;
				}

				.pbg-welcome-feature {
					text-align: center;
					padding: 24px 16px;
					background: #f8fafc;
					border-radius: 12px;
					transition: all 0.2s ease;
					border: 1px solid #e2e8f0;
				}

				.pbg-welcome-feature:hover {
					transform: translateY(-3px);
					box-shadow: 0 8px 25px rgba(0, 0, 0, 0.08);
					border-color: #cbd5e1;
				}

				.pbg-welcome-feature-icon {
					width: 50px;
					height: 50px;
					background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
					border-radius: 12px;
					margin: 0 auto 16px;
					display: flex;
					align-items: center;
					justify-content: center;
				}

				.pbg-welcome-feature-icon .dashicons {
					font-size: 28px;
					width: 28px;
					height: 28px;
					color: #ffffff;
				}

				.pbg-welcome-feature h3 {
					font-size: 16px;
					color: #1d2327;
					margin: 0 0 8px 0;
					font-weight: 600;
				}

				.pbg-welcome-feature p {
					font-size: 13px;
					color: #64748b;
					line-height: 1.5;
					margin: 0;
				}

				.pbg-welcome-quick-start {
					background: #fef3c7;
					border: 1px solid #fcd34d;
					border-radius: 12px;
					padding: 24px;
					margin-bottom: 30px;
				}

				.pbg-welcome-quick-start h3 {
					font-size: 18px;
					color: #92400e;
					margin: 0 0 16px 0;
					display: flex;
					align-items: center;
					gap: 8px;
				}

				.pbg-welcome-quick-start h3 .dashicons {
					font-size: 22px;
				}

				.pbg-welcome-quick-start ol {
					margin: 0 0 0 20px;
					padding: 0;
				}

				.pbg-welcome-quick-start li {
					font-size: 14px;
					color: #78350f;
					margin-bottom: 10px;
					line-height: 1.5;
				}

				.pbg-welcome-quick-start li:last-child {
					margin-bottom: 0;
				}

				.pbg-welcome-quick-start code {
					background: #fffbeb;
					padding: 2px 6px;
					border-radius: 4px;
					font-family: ui-monospace, SFMono-Regular, Consolas, monospace;
					font-size: 12px;
					color: #b45309;
					border: 1px solid #fde68a;
				}

				.pbg-welcome-actions {
					display: flex;
					gap: 16px;
					justify-content: center;
				}

				.pbg-welcome-btn {
					display: inline-flex;
					align-items: center;
					gap: 8px;
					padding: 12px 24px;
					font-size: 14px;
					font-weight: 600;
					border-radius: 8px;
					text-decoration: none;
					transition: all 0.2s ease;
				}

				.pbg-welcome-btn--primary {
					background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
					color: #ffffff;
					box-shadow: 0 2px 8px rgba(102, 126, 234, 0.25);
				}

				.pbg-welcome-btn--primary:hover {
					transform: translateY(-1px);
					box-shadow: 0 4px 12px rgba(102, 126, 234, 0.35);
				}

				.pbg-welcome-btn--secondary {
					background: #f1f5f9;
					color: #475569;
					border: 1px solid #e2e8f0;
				}

				.pbg-welcome-btn--secondary:hover {
					background: #e2e8f0;
					border-color: #cbd5e1;
				}

				.pbg-welcome-btn .dashicons {
					font-size: 16px;
					width: 16px;
					height: 16px;
				}

				@media (max-width: 1200px) {
					.pbg-welcome-wrapper {
						margin: 0;
						border-radius: 0;
					}
				}

				@media (max-width: 782px) {
					.pbg-welcome-features {
						grid-template-columns: 1fr;
					}

					.pbg-welcome-header {
						padding: 40px 24px;
					}

					.pbg-welcome-content {
						padding: 24px;
					}

					.pbg-welcome-header h1 {
						font-size: 28px;
					}

					.pbg-welcome-actions {
						flex-direction: column;
					}

					.pbg-welcome-btn {
						width: 100%;
						justify-content: center;
					}
				}
			</style>

			<div class="pbg-welcome-wrapper">
				<div class="pbg-welcome-header">
					<div class="pbg-welcome-logo">
						<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none">
							<path d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z" fill="white"/>
						</svg>
					</div>
					<h1><?php esc_html_e( 'Welcome to ProductPageGlut', 'productbaseglut' ); ?></h1>
					<p class="pbg-welcome-subtitle"><?php esc_html_e( 'Complete WooCommerce Product Page Builder', 'productbaseglut' ); ?></p>
				</div>

				<div class="pbg-welcome-content">
					<div class="pbg-welcome-thank-you">
						<h2><?php esc_html_e( 'Thank you for installing ProductPageGlut!', 'productbaseglut' ); ?></h2>
						<p><?php esc_html_e( 'You\'re just a few steps away from creating beautiful, custom product pages for your WooCommerce store.', 'productbaseglut' ); ?></p>
					</div>

					<div class="pbg-welcome-features">
						<div class="pbg-welcome-feature">
							<div class="pbg-welcome-feature-icon">
								<span class="dashicons dashicons-admin-customizer"></span>
							</div>
							<h3><?php esc_html_e( 'Product Page Builder', 'productbaseglut' ); ?></h3>
							<p><?php esc_html_e( 'Create stunning product pages with drag & drop builder and pre-designed templates.', 'productbaseglut' ); ?></p>
						</div>

						<div class="pbg-welcome-feature">
							<div class="pbg-welcome-feature-icon">
								<span class="dashicons dashicons-forms"></span>
							</div>
							<h3><?php esc_html_e( 'Product Custom Fields', 'productbaseglut' ); ?></h3>
							<p><?php esc_html_e( 'Add unlimited custom fields to your products with various field types.', 'productbaseglut' ); ?></p>
						</div>

						<div class="pbg-welcome-feature">
							<div class="pbg-welcome-feature-icon">
								<span class="dashicons dashicons-yes-alt"></span>
							</div>
							<h3><?php esc_html_e( 'Product Swatches', 'productbaseglut' ); ?></h3>
							<p><?php esc_html_e( 'Beautiful color, image, and button swatches for variable products.', 'productbaseglut' ); ?></p>
						</div>

						<div class="pbg-welcome-feature">
							<div class="pbg-welcome-feature-icon">
								<span class="dashicons dashicons-awards"></span>
							</div>
							<h3><?php esc_html_e( 'Product Badges', 'productbaseglut' ); ?></h3>
							<p><?php esc_html_e( 'Highlight products with eye-catching badges and labels.', 'productbaseglut' ); ?></p>
						</div>

						<div class="pbg-welcome-feature">
							<div class="pbg-welcome-feature-icon">
								<span class="dashicons dashicons-heart"></span>
							</div>
							<h3><?php esc_html_e( 'Wishlist', 'productbaseglut' ); ?></h3>
							<p><?php esc_html_e( 'Let customers save their favorite products to wishlists.', 'productbaseglut' ); ?></p>
						</div>

						<div class="pbg-welcome-feature">
							<div class="pbg-welcome-feature-icon">
								<span class="dashicons dashicons-chart-bar"></span>
							</div>
							<h3><?php esc_html_e( 'Product Comparison', 'productbaseglut' ); ?></h3>
							<p><?php esc_html_e( 'Enable customers to compare products side by side.', 'productbaseglut' ); ?></p>
						</div>
					</div>

					<div class="pbg-welcome-quick-start">
						<h3>
							<span class="dashicons dashicons-superhero-alt"></span>
							<?php esc_html_e( 'Quick Start Guide', 'productbaseglut' ); ?>
						</h3>
						<ol>
							<li><?php esc_html_e( 'Navigate to the Product Pages section to create your first product page layout', 'productbaseglut' ); ?></li>
							<li><?php esc_html_e( 'Choose from pre-designed templates or create your own from scratch', 'productbaseglut' ); ?></li>
							<li><?php esc_html_e( 'Customize product elements like title, price, add to cart, and more', 'productbaseglut' ); ?></li>
							<li><?php esc_html_e( 'Add custom fields, swatches, and badges to enhance product display', 'productbaseglut' ); ?></li>
							<li><?php esc_html_e( 'Assign layouts to specific products or categories for targeted designs', 'productbaseglut' ); ?></li>
						</ol>
					</div>

					<div class="pbg-welcome-actions">
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=shopglut_layouts&view=singleproduct' ) ); ?>" class="pbg-welcome-btn pbg-welcome-btn--primary">
							<span class="dashicons dashicons-arrow-right-alt"></span>
							<?php esc_html_e( 'Get Started', 'productbaseglut' ); ?>
						</a>
						<a href="https://documentation.appglut.com/?utm_source=productbaseglut-welcome&utm_medium=referral&utm_campaign=welcome" target="_blank" class="pbg-welcome-btn pbg-welcome-btn--secondary">
							<span class="dashicons dashicons-book"></span>
							<?php esc_html_e( 'View Documentation', 'productbaseglut' ); ?>
						</a>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	public static function get_instance() {
		static $instance;
		if ( is_null( $instance ) ) {
			$instance = new self();
		}
		return $instance;
	}
}
