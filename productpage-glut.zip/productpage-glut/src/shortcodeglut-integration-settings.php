<?php

if ( ! defined( 'ABSPATH' ) ) {
	die;
}

// Set a unique slug-like ID
$PRODUCTPAGEGLUT_INTEGRATION_SETTINGS = 'shopglut_integration_settings';

// Create options
AGSHOPGLUT::createOptions( $PRODUCTPAGEGLUT_INTEGRATION_SETTINGS, array(
	// menu settings
	'menu_title' => esc_html__( 'Global Settings', 'productpageglut' ),
	'show_bar_menu' => false,
	'hide_menu' => false,
	'menu_slug' => 'shopglut_integration_settings',
	'menu_parent' => 'productpageglut_layouts',
	'menu_type' => 'submenu',
	'menu_capability' => 'manage_options',
	'framework_title' => esc_html__( 'Integration Settings', 'productpageglut' ),
	'show_reset_section' => true,
	'framework_class' => 'shopglut_integration_settings',
	'footer_credit' => __( "Productpageglut", 'productpageglut' ),
	'menu_position' => 6,
) );

// Create a top-tab
AGSHOPGLUT::createSection( $PRODUCTPAGEGLUT_INTEGRATION_SETTINGS, array(
	'id' => 'shortcodes_tab',
	'title' => __( 'ShortcodeGlut', 'productpageglut' ),
	'icon' => 'fa fa-plug',
) );

// Create a sub-tab
AGSHOPGLUT::createSection( $PRODUCTPAGEGLUT_INTEGRATION_SETTINGS, array(
	'parent' => 'shortcodes_tab',
	'title' => __( 'General', 'productpageglut' ),
	'fields' => array(

		array(
			'id' => 'shortcodeglut-show-menu',
			'type' => 'switcher',
			'title' => __( 'Show ShortcodeGlut Menu', 'productpageglut' ),
			'desc' => __( 'When enabled, ShortcodeGlut will show its own admin menu even when Productpageglut is active.', 'productpageglut' ),
			'text_on' => __( 'Yes', 'productpageglut' ),
			'text_off' => __( 'No', 'productpageglut' ),
			'default' => 0,
		),

	)
) );

// Create WishGlut tab
AGSHOPGLUT::createSection( $PRODUCTPAGEGLUT_INTEGRATION_SETTINGS, array(
	'id' => 'wishglut_tab',
	'title' => __( 'WishGlut', 'productpageglut' ),
	'icon' => 'fa fa-heart',
) );

// Create WishGlut sub-tab
AGSHOPGLUT::createSection( $PRODUCTPAGEGLUT_INTEGRATION_SETTINGS, array(
	'parent' => 'wishglut_tab',
	'title' => __( 'General', 'productpageglut' ),
	'fields' => array(

		array(
			'id' => 'wishglut-show-menu',
			'type' => 'switcher',
			'title' => __( 'Show WishGlut Menu', 'productpageglut' ),
			'desc' => __( 'When enabled, WishGlut will show its own admin menu even when Productpageglut is active.', 'productpageglut' ),
			'text_on' => __( 'Yes', 'productpageglut' ),
			'text_off' => __( 'No', 'productpageglut' ),
			'default' => 0,
		),

	)
) );

// Create CheckoutGlut tab
AGSHOPGLUT::createSection( $PRODUCTPAGEGLUT_INTEGRATION_SETTINGS, array(
	'id' => 'checkoutglut_tab',
	'title' => __( 'CheckoutGlut', 'productpageglut' ),
	'icon' => 'fa fa-check-square',
) );

// Create CheckoutGlut sub-tab
AGSHOPGLUT::createSection( $PRODUCTPAGEGLUT_INTEGRATION_SETTINGS, array(
	'parent' => 'checkoutglut_tab',
	'title' => __( 'General', 'productpageglut' ),
	'fields' => array(

		array(
			'id' => 'checkoutglut-show-menu',
			'type' => 'switcher',
			'title' => __( 'Show CheckoutGlut Menu', 'productpageglut' ),
			'desc' => __( 'When enabled, CheckoutGlut will show its own admin menu even when Productpageglut is active.', 'productpageglut' ),
			'text_on' => __( 'Yes', 'productpageglut' ),
			'text_off' => __( 'No', 'productpageglut' ),
			'default' => 0,
		),

	)
) );

// Create Data Management tab
AGSHOPGLUT::createSection( $PRODUCTPAGEGLUT_INTEGRATION_SETTINGS, array(
	'id' => 'data_management_tab',
	'title' => __( 'Data Management', 'productpageglut' ),
	'icon' => 'fa fa-database',
) );

// Create Data Management sub-tab
AGSHOPGLUT::createSection( $PRODUCTPAGEGLUT_INTEGRATION_SETTINGS, array(
	'parent' => 'data_management_tab',
	'title' => __( 'Database Tables', 'productpageglut' ),
	'description' => __( '<div style="background: #fff3cd; border: 1px solid #ffc107; border-left: 4px solid #ffc107; padding: 15px; margin-bottom: 20px; border-radius: 4px;"><strong>⚠️ Warning:</strong> These actions are destructive and cannot be undone. Always backup your database before performing these operations.</div>', 'productpageglut' ),
	'fields' => array(

		array(
			'id' => 'shopglut_db_tables_manager',
			'type' => 'database_manager'
		)

	)
) );

// Create ProductPageGlut tab
AGSHOPGLUT::createSection( $PRODUCTPAGEGLUT_INTEGRATION_SETTINGS, array(
	'id' => 'productpageglut_tab',
	'title' => __( 'ProductPageGlut', 'productpageglut' ),
	'icon' => 'fa fa-cart',
) );

// Create ProductPageGlut sub-tab
AGSHOPGLUT::createSection( $PRODUCTPAGEGLUT_INTEGRATION_SETTINGS, array(
	'parent' => 'productpageglut_tab',
	'title' => __( 'General', 'productpageglut' ),
	'fields' => array(

		array(
			'id' => 'productpageglut-show-menu',
			'type' => 'switcher',
			'title' => __( 'Show ProductPageGlut Menu', 'productpageglut' ),
			'desc' => __( 'When enabled, ProductPageGlut will show its own admin menu even when ShopGlut is active.', 'productpageglut' ),
			'text_on' => __( 'Yes', 'productpageglut' ),
			'text_off' => __( 'No', 'productpageglut' ),
			'default' => 0,
		),

	)
) );

// Allow other plugins to add settings
do_action( 'shopglut_integration_settings', $PRODUCTPAGEGLUT_INTEGRATION_SETTINGS );
