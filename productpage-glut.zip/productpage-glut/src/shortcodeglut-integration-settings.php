<?php

if ( ! defined( 'ABSPATH' ) ) {
	die;
}

// Set a unique slug-like ID
$PRODUCTBASEGLUT_INTEGRATION_SETTINGS = 'shopglut_integration_settings';

// Create options
AGSHOPGLUT::createOptions( $PRODUCTBASEGLUT_INTEGRATION_SETTINGS, array(
	// menu settings
	'menu_title' => esc_html__( 'Global Settings', 'productbaseglut' ),
	'show_bar_menu' => false,
	'hide_menu' => false,
	'menu_slug' => 'shopglut_integration_settings',
	'menu_parent' => 'shopglut_layouts',
	'menu_type' => 'submenu',
	'menu_capability' => 'manage_options',
	'framework_title' => esc_html__( 'Integration Settings', 'productbaseglut' ),
	'show_reset_section' => true,
	'framework_class' => 'shopglut_integration_settings',
	'footer_credit' => __( "Productbaseglut", 'productbaseglut' ),
	'menu_position' => 6,
) );

// Create a top-tab
AGSHOPGLUT::createSection( $PRODUCTBASEGLUT_INTEGRATION_SETTINGS, array(
	'id' => 'shortcodes_tab',
	'title' => __( 'ShortcodeGlut', 'productbaseglut' ),
	'icon' => 'fa fa-plug',
) );

// Create a sub-tab
AGSHOPGLUT::createSection( $PRODUCTBASEGLUT_INTEGRATION_SETTINGS, array(
	'parent' => 'shortcodes_tab',
	'title' => __( 'General', 'productbaseglut' ),
	'fields' => array(

		array(
			'id' => 'shortcodeglut-show-menu',
			'type' => 'switcher',
			'title' => __( 'Show ShortcodeGlut Menu', 'productbaseglut' ),
			'desc' => __( 'When enabled, ShortcodeGlut will show its own admin menu even when Productbaseglut is active.', 'productbaseglut' ),
			'text_on' => __( 'Yes', 'productbaseglut' ),
			'text_off' => __( 'No', 'productbaseglut' ),
			'default' => 0,
		),

	)
) );

// Create WishGlut tab
AGSHOPGLUT::createSection( $PRODUCTBASEGLUT_INTEGRATION_SETTINGS, array(
	'id' => 'wishglut_tab',
	'title' => __( 'WishGlut', 'productbaseglut' ),
	'icon' => 'fa fa-heart',
) );

// Create WishGlut sub-tab
AGSHOPGLUT::createSection( $PRODUCTBASEGLUT_INTEGRATION_SETTINGS, array(
	'parent' => 'wishglut_tab',
	'title' => __( 'General', 'productbaseglut' ),
	'fields' => array(

		array(
			'id' => 'wishglut-show-menu',
			'type' => 'switcher',
			'title' => __( 'Show WishGlut Menu', 'productbaseglut' ),
			'desc' => __( 'When enabled, WishGlut will show its own admin menu even when Productbaseglut is active.', 'productbaseglut' ),
			'text_on' => __( 'Yes', 'productbaseglut' ),
			'text_off' => __( 'No', 'productbaseglut' ),
			'default' => 0,
		),

	)
) );

// Create CheckoutGlut tab
AGSHOPGLUT::createSection( $PRODUCTBASEGLUT_INTEGRATION_SETTINGS, array(
	'id' => 'checkoutglut_tab',
	'title' => __( 'CheckoutGlut', 'productbaseglut' ),
	'icon' => 'fa fa-check-square',
) );

// Create CheckoutGlut sub-tab
AGSHOPGLUT::createSection( $PRODUCTBASEGLUT_INTEGRATION_SETTINGS, array(
	'parent' => 'checkoutglut_tab',
	'title' => __( 'General', 'productbaseglut' ),
	'fields' => array(

		array(
			'id' => 'checkoutglut-show-menu',
			'type' => 'switcher',
			'title' => __( 'Show CheckoutGlut Menu', 'productbaseglut' ),
			'desc' => __( 'When enabled, CheckoutGlut will show its own admin menu even when Productbaseglut is active.', 'productbaseglut' ),
			'text_on' => __( 'Yes', 'productbaseglut' ),
			'text_off' => __( 'No', 'productbaseglut' ),
			'default' => 0,
		),

	)
) );

// Create Data Management tab
AGSHOPGLUT::createSection( $PRODUCTBASEGLUT_INTEGRATION_SETTINGS, array(
	'id' => 'data_management_tab',
	'title' => __( 'Data Management', 'productbaseglut' ),
	'icon' => 'fa fa-database',
) );

// Create Data Management sub-tab
AGSHOPGLUT::createSection( $PRODUCTBASEGLUT_INTEGRATION_SETTINGS, array(
	'parent' => 'data_management_tab',
	'title' => __( 'Database Tables', 'productbaseglut' ),
	'description' => __( '<div style="background: #fff3cd; border: 1px solid #ffc107; border-left: 4px solid #ffc107; padding: 15px; margin-bottom: 20px; border-radius: 4px;"><strong>⚠️ Warning:</strong> These actions are destructive and cannot be undone. Always backup your database before performing these operations.</div>', 'productbaseglut' ),
	'fields' => array(

		array(
			'id' => 'shopglut_db_tables_manager',
			'type' => 'database_manager'
		)

	)
) );

// Create ProductPageGlut tab
AGSHOPGLUT::createSection( $PRODUCTBASEGLUT_INTEGRATION_SETTINGS, array(
	'id' => 'productpageglut_tab',
	'title' => __( 'ProductPageGlut', 'productbaseglut' ),
	'icon' => 'fa fa-cart',
) );

// Create ProductPageGlut sub-tab
AGSHOPGLUT::createSection( $PRODUCTBASEGLUT_INTEGRATION_SETTINGS, array(
	'parent' => 'productpageglut_tab',
	'title' => __( 'General', 'productbaseglut' ),
	'fields' => array(

		array(
			'id' => 'productpageglut-show-menu',
			'type' => 'switcher',
			'title' => __( 'Show ProductPageGlut Menu', 'productbaseglut' ),
			'desc' => __( 'When enabled, ProductPageGlut will show its own admin menu even when ShopGlut is active.', 'productbaseglut' ),
			'text_on' => __( 'Yes', 'productbaseglut' ),
			'text_off' => __( 'No', 'productbaseglut' ),
			'default' => 0,
		),

	)
) );

// Allow other plugins to add settings
do_action( 'shopglut_integration_settings', $PRODUCTBASEGLUT_INTEGRATION_SETTINGS );
