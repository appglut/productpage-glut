<?php

use Productpageglut\layouts\productPage\dataManage as SingleProductDataManage;



if ( ! defined( 'ABSPATH' ) ) {
	die;
} // Cannot access directly.

/**
 *
 * Field: Preview
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */

if ( ! class_exists( 'AGPRODUCTPAGEGLUT_preview' ) ) {
	/**
	 *
	 * Field: shortcode
	 *
	 * @since 2.0.15
	 * @version 2.0.15
	 */
	class AGPRODUCTPAGEGLUT_preview extends AGSHOPGLUTP {

		//use Productpageglut\enhancements\Filters\FilterTrait;


		/**
		 * Shortcode field constructor.
		 */
		public function __construct( $field, $value = '', $unique = '', $where = '', $parent = '' ) {
			parent::__construct( $field, $value, $unique, $where, $parent );
		}

		/**
		 * Render
		 *
		 * @return void
		 */
		public function render() {


		 
			if ( isset( $_GET['page'] ) && isset( $_GET['editor'] ) &&
			     ( ( 'productpageglut_layouts' === $_GET['page'] && 'product_page' === $_GET['editor'] ) ||
			       ( 'shopglut_layouts' === $_GET['page'] && 'productpageglut' === $_GET['editor'] ) )
			)  {
				$layout_id = isset( $_GET['layout_id'] ) ? intval( $_GET['layout_id'] ) : 0;

				// Define preview mode constant for demo editor
				if (!defined('PRODUCTPAGEGLUT_PREVIEW_MODE')) {
					define('PRODUCTPAGEGLUT_PREVIEW_MODE', true);
				}

				// Filter to add form element to allowed HTML for preview
				add_filter('wp_kses_allowed_html', function($allowed_html, $context) {
					if ($context === 'post') {
						// Add form element
						$allowed_html['form'] = array(
							'action' => true,
							'method' => true,
							'class' => true,
							'id' => true,
							'novalidate' => true,
							'enctype' => true,
							'style' => true,
							'name' => true,
							'target' => true,
							'accept' => true,
							'accept-charset' => true,
							'autocomplete' => true,
						);
						// Add label with for attribute
						$allowed_html['label'] = array(
							'class' => true,
							'id' => true,
							'style' => true,
							'for' => true,
						);
					}
					return $allowed_html;
				}, 10, 2);

				$single_product_data_manage = new SingleProductDataManage();

				// Get base allowed HTML
				$allowed_html = wp_kses_allowed_html( 'post' );

				// Allow style tags and link tags
				$allowed_html['style'] = array();
				$allowed_html['link'] = array(
					'rel' => true,
					'type' => true,
					'href' => true,
					'media' => true,
				);

				// Add div, span, h1-h6, p, label, strong, em with all common attributes
				$block_elements = array('div', 'span', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'p', 'strong', 'em', 'small', 'ul', 'ol', 'li', 'section', 'article', 'dl', 'dt', 'dd');
				foreach ($block_elements as $tag) {
					$allowed_html[$tag] = array(
						'class' => true,
						'id' => true,
						'style' => true,
						'data-*' => true,
					);
				}

				// Label element needs 'for' attribute
				$allowed_html['label'] = array(
					'class' => true,
					'id' => true,
					'style' => true,
					'for' => true,
				);

				// Span element needs comprehensive attributes
				$allowed_html['span'] = array(
					'class' => true,
					'id' => true,
					'style' => true,
					'data-*' => true,
					'aria-hidden' => true,
				);

				// Form element with all necessary attributes
				$allowed_html['form'] = array(
					'action' => true,
					'method' => true,
					'class' => true,
					'id' => true,
					'novalidate' => true,
					'enctype' => true,
					'style' => true,
					'name' => true,
					'target' => true,
					'accept' => true,
					'accept-charset' => true,
					'autocomplete' => true,
				);

				// Input element with comprehensive attributes
				$allowed_html['input'] = array(
					'type' => true,
					'name' => true,
					'value' => true,
					'placeholder' => true,
					'class' => true,
					'id' => true,
					'min' => true,
					'max' => true,
					'step' => true,
					'onchange' => true,
					'onclick' => true,
					'required' => true,
					'checked' => true,
					'disabled' => true,
					'readonly' => true,
					'size' => true,
					'style' => true,
					'width' => true,
					'height' => true,
					'alt' => true,
					'src' => true,
				);
				$allowed_html['button'] = array(
					'type' => true,
					'class' => true,
					'id' => true,
					'onclick' => true,
					'disabled' => true,
					'name' => true,
					'value' => true,
					'style' => true,
					'form' => true,
				);
				$allowed_html['select'] = array(
					'name' => true,
					'class' => true,
					'id' => true,
					'onchange' => true,
					'required' => true,
					'multiple' => true,
					'size' => true,
					'style' => true,
					'position' => true,
					'opacity' => true,
					'width' => true,
					'height' => true,
					'form' => true,
				);
				$allowed_html['option'] = array(
					'value' => true,
					'selected' => true,
					'disabled' => true,
					'label' => true,
				);
				$allowed_html['textarea'] = array(
					'name' => true,
					'rows' => true,
					'cols' => true,
					'placeholder' => true,
					'class' => true,
					'id' => true,
					'required' => true,
					'style' => true,
					'minlength' => true,
					'maxlength' => true,
					'wrap' => true,
					'form' => true,
				);

				// Add SVG support for icons
				$allowed_html['svg'] = array(
					'width' => true,
					'height' => true,
					'viewbox' => true,
					'fill' => true,
					'stroke' => true,
					'stroke-width' => true,
					'stroke-linecap' => true,
					'stroke-linejoin' => true,
					'class' => true,
					'xmlns' => true,
					'style' => true,
				);
				$allowed_html['path'] = array(
					'd' => true,
					'fill' => true,
					'stroke' => true,
					'stroke-width' => true,
					'stroke-linecap' => true,
				);
				$allowed_html['polyline'] = array(
					'points' => true,
					'fill' => true,
					'stroke' => true,
				);
				$allowed_html['line'] = array(
					'x1' => true,
					'y1' => true,
					'x2' => true,
					'y2' => true,
					'stroke' => true,
					'stroke-width' => true,
				);
				$allowed_html['circle'] = array(
					'cx' => true,
					'cy' => true,
					'r' => true,
					'fill' => true,
					'stroke' => true,
				);
				$allowed_html['rect'] = array(
					'x' => true,
					'y' => true,
					'width' => true,
					'height' => true,
					'rx' => true,
					'ry' => true,
					'fill' => true,
				);

				// Add i tag for FontAwesome icons with comprehensive attributes
				$allowed_html['i'] = array(
					'class' => true,
					'data-rating' => true,
					'style' => true,
					'aria-hidden' => true,
				);

				// Add table elements for product attributes
				$table_elements = array('table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'caption');
				foreach ($table_elements as $tag) {
					$allowed_html[$tag] = array(
						'class' => true,
						'id' => true,
						'style' => true,
						'colspan' => true,
						'rowspan' => true,
						'scope' => true,
					);
				}

				// Add img with full attributes
				$allowed_html['img'] = array(
					'src' => true,
					'alt' => true,
					'class' => true,
					'id' => true,
					'style' => true,
					'width' => true,
					'height' => true,
					'srcset' => true,
					'sizes' => true,
					'loading' => true,
					'data-src' => true,
				);

				// Add a tag
				$allowed_html['a'] = array(
					'href' => true,
					'class' => true,
					'id' => true,
					'style' => true,
					'title' => true,
					'target' => true,
					'rel' => true,
					'data-*' => true,
				);

				// Add br and hr
				$allowed_html['br'] = array('class' => true, 'style' => true);
				$allowed_html['hr'] = array('class' => true, 'style' => true);

				// Allow style and data-* attributes on all elements
				foreach ( $allowed_html as $tag => $attributes ) {
					if ( is_array( $attributes ) ) {
						$allowed_html[ $tag ]['style'] = true;
						$allowed_html[ $tag ]['class'] = true;
						$allowed_html[ $tag ]['id'] = true;
						// Allow data-* attributes
						$allowed_html[ $tag ]['data-*'] = true;
						if (in_array($tag, ['i', 'div', 'span', 'button', 'input', 'select', 'a'])) {
							$allowed_html[ $tag ]['data-rating'] = true;
						}
					}
				}

				// Expand safe_style_css filter to allow all common CSS properties
				add_filter('safe_style_css', function($styles) {
					$additional_styles = array(
						'display', 'visibility', 'opacity', 'position', 'top', 'right', 'bottom', 'left',
						'width', 'height', 'min-width', 'max-width', 'min-height', 'max-height',
						'margin', 'margin-top', 'margin-right', 'margin-bottom', 'margin-left',
						'padding', 'padding-top', 'padding-right', 'padding-bottom', 'padding-left',
						'border', 'border-top', 'border-right', 'border-bottom', 'border-left',
						'border-color', 'border-style', 'border-width', 'border-radius',
						'background', 'background-color', 'background-image', 'background-position', 'background-size', 'background-repeat',
						'color', 'font', 'font-family', 'font-size', 'font-weight', 'font-style',
						'text-align', 'text-decoration', 'text-transform', 'line-height', 'letter-spacing', 'word-spacing',
						'overflow', 'overflow-x', 'overflow-y',
						'float', 'clear',
						'flex', 'flex-direction', 'flex-wrap', 'justify-content', 'align-items', 'align-content', 'flex-grow', 'flex-shrink', 'flex-basis',
						'grid', 'grid-template-columns', 'grid-template-rows', 'grid-gap', 'grid-column', 'grid-row',
						'transform', 'transition', 'animation',
						'box-shadow', 'text-shadow',
						'cursor', 'pointer-events',
						'z-index', 'vertical-align',
						'white-space', 'word-wrap', 'word-break',
						'list-style', 'list-style-type', 'list-style-position',
						'table-layout', 'border-collapse', 'border-spacing',
						'caption-side', 'empty-cells',
					);
					return array_merge($styles, $additional_styles);
				});

				// Get the preview content
				$preview_content = $single_product_data_manage->shopglut_render_singleplayout_preview( $layout_id );

				// Output with wp_kses filtering
				echo wp_kses( $preview_content, $allowed_html );

			}
			
	


		}

		/**
		 * Get custom allowed HTML tags for filter preview
		 */
		private function get_filter_allowed_tags() {
			$allowed_tags = wp_kses_allowed_html( 'post' );
			$allowed_tags['style'] = array();

			// Allow input elements for checkboxes and radios with comprehensive attributes
			$allowed_tags['input'] = array(
				'type' => true,
				'name' => true,
				'value' => true,
				'checked' => true,
				'class' => true,
				'id' => true,
				'style' => true,
				'disabled' => true,
				'readonly' => true,
				'required' => true,
			);

			// Allow span for checkmarks and radio marks
			$allowed_tags['span'] = array(
				'class' => true,
				'style' => true,
			);

			// Allow div for filter containers
			$allowed_tags['div'] = array(
				'class' => true,
				'id' => true,
				'style' => true,
			);

			// Allow label for proper accessibility
			$allowed_tags['label'] = array(
				'class' => true,
				'for' => true,
				'style' => true,
			);

			// Allow strong for parent categories
			$allowed_tags['strong'] = array(
				'style' => true,
			);

			// Allow select and option elements for dropdown filters
			$allowed_tags['select'] = array(
				'name' => true,
				'class' => true,
				'id' => true,
				'style' => true,
				'disabled' => true,
				'required' => true,
			);

			$allowed_tags['option'] = array(
				'value' => true,
				'selected' => true,
				'disabled' => true,
			);

			// Allow button elements for apply/reset buttons
			$allowed_tags['button'] = array(
				'type' => true,
				'class' => true,
				'style' => true,
				'disabled' => true,
			);

			// Allow style attribute on all elements
			foreach ( $allowed_tags as $tag => $attributes ) {
				if ( is_array( $attributes ) ) {
					$allowed_tags[ $tag ]['style'] = true;
				}
			}

			return $allowed_tags;
		}

		/**
		 * Recursive method to render category hierarchy for filter preview
		 */
		private function render_category_hierarchy_preview( $term, $type, $show_count, $is_radio = false ) {
			$term_id = is_object( $term ) ? $term->term_id : $term['term_id'];
			$term_name = is_object( $term ) ? $term->name : $term['name'];
			$term_count = is_object( $term ) ? $term->count : ( isset( $term['count'] ) ? $term['count'] : 0 );
			$has_children = is_object( $term ) && ! empty( $term->children ) && ! is_wp_error( $term->children );
			$is_parent = !$this->has_parent( $term );

			$html = '<label class="' . esc_attr( $is_radio ? 'productpageglut-filter-radio-label' : 'productpageglut-filter-checkbox' ) . '">';
			$html .= '<input type="' . esc_attr( $is_radio ? 'radio' : 'checkbox' ) . '" name="' . esc_attr( $type ) . ( $is_radio ? '' : '[]' ) . '" value="' . esc_attr( $term_id ) . '">';
			$html .= '<span class="' . esc_attr( $is_radio ? 'radio-mark' : 'checkmark' ) . '"></span>';
			$html .= $is_parent ? '<strong>' . esc_html( $term_name ) . '</strong>' : esc_html( $term_name );
			if ( $show_count ) {
				$html .= ' <span class="count">(' . esc_html( $term_count ) . ')</span>';
			}
			$html .= '</label>';

			// Render children recursively if they exist
			if ( $has_children ) {
				foreach ( $term->children as $child ) {
					$html .= '<div style="margin-left: 20px;">' . $this->render_category_hierarchy_preview( $child, $type, $show_count, $is_radio ) . '</div>';
				}
			}

			return $html;
		}

		/**
		 * Check if a term has a parent
		 */
		private function has_parent( $term ) {
			if ( is_object( $term ) ) {
				return isset( $term->parent ) && $term->parent != 0;
			}
			return false;
		}

		private function display_terms_with_appearance( $type, $terms, $appearance_type, $options = array() ) {
			if ( empty( $terms ) ) {
				return '';
			}

			$html = '';
			$images = isset( $options['images'] ) ? $options['images'] : array();
			$colors = isset( $options['colors'] ) ? $options['colors'] : array();
			$show_count = isset( $options['show_count'] ) ? $options['show_count'] : false;

			switch ( $appearance_type ) {
				case 'check-list':
					$html .= '<div class="productpageglut-filter-checklist">';
					foreach ( $terms as $term ) {
						// Use recursive rendering to handle hierarchy
						$html .= $this->render_category_hierarchy_preview( $term, $type, $show_count, false );
					}
					$html .= '</div>';
					break;

				case 'radio':
					$html .= '<div class="productpageglut-filter-radio">';
					foreach ( $terms as $term ) {
						// Use recursive rendering to handle hierarchy
						$html .= $this->render_category_hierarchy_preview( $term, $type, $show_count, true );
					}
					$html .= '</div>';
					break;

				case 'dropdown':
					$html .= '<select name="' . esc_attr( $type ) . '" class="productpageglut-filter-dropdown">';
					$html .= '<option value="">Select ' . ucwords( str_replace( '-', ' ', $type ) ) . '</option>';
					foreach ( $terms as $term ) {
						$term_id = is_object( $term ) ? $term->term_id : $term['term_id'];
						$term_name = is_object( $term ) ? $term->name : $term['name'];
						$term_count = is_object( $term ) ? $term->count : ( isset( $term['count'] ) ? $term['count'] : 0 );

						$count_text = $show_count ? ' (' . $term_count . ')' : '';
						$html .= '<option value="' . esc_attr( $term_id ) . '">' . esc_html( $term_name . $count_text ) . '</option>';
					}
					$html .= '</select>';
					break;

				case 'button':
					$html .= '<div class="productpageglut-filter-buttons">';
					foreach ( $terms as $term ) {
						$term_id = is_object( $term ) ? $term->term_id : $term['term_id'];
						$term_name = is_object( $term ) ? $term->name : $term['name'];
						$term_count = is_object( $term ) ? $term->count : ( isset( $term['count'] ) ? $term['count'] : 0 );

						$html .= '<button type="button" class="productpageglut-filter-button" data-value="' . esc_attr( $term_id ) . '">';
						$html .= esc_html( $term_name );
						if ( $show_count ) {
							$html .= ' <span class="count">(' . esc_html( $term_count ) . ')</span>';
						}
						$html .= '</button>';
					}
					$html .= '</div>';
					break;

				case 'color':
					$html .= '<div class="productpageglut-filter-colors">';
					foreach ( $terms as $term ) {
						$term_id = is_object( $term ) ? $term->term_id : $term['term_id'];
						$term_name = is_object( $term ) ? $term->name : $term['name'];
						$term_count = is_object( $term ) ? $term->count : ( isset( $term['count'] ) ? $term['count'] : 0 );

						$color = isset( $colors[$term_id] ) ? $colors[$term_id] : '#cccccc';
						$html .= '<span class="productpageglut-filter-color" data-value="' . esc_attr( $term_id ) . '" title="' . esc_attr( $term_name ) . '">';
						$html .= '<span class="color-swatch" style="background-color: ' . esc_attr( $color ) . '"></span>';
						if ( $show_count ) {
							$html .= ' <span class="count">(' . esc_html( $term_count ) . ')</span>';
						}
						$html .= '</span>';
					}
					$html .= '</div>';
					break;

				case 'image':
					$html .= '<div class="productpageglut-filter-images">';
					foreach ( $terms as $term ) {
						$term_id = is_object( $term ) ? $term->term_id : $term['term_id'];
						$term_name = is_object( $term ) ? $term->name : $term['name'];
						$term_count = is_object( $term ) ? $term->count : ( isset( $term['count'] ) ? $term['count'] : 0 );

						$image_url = isset( $images[$term_id] ) ? $images[$term_id] : '';
						$html .= '<span class="productpageglut-filter-image" data-value="' . esc_attr( $term_id ) . '" title="' . esc_attr( $term_name ) . '">';
						if ( $image_url ) {
							$html .= '<img src="' . esc_url( $image_url ) . '" alt="' . esc_attr( $term_name ) . '">';
						} else {
							$html .= '<span class="no-image">' . esc_html( substr( $term_name, 0, 2 ) ) . '</span>';
						}
						if ( $show_count ) {
							$html .= ' <span class="count">(' . esc_html( $term_count ) . ')</span>';
						}
						$html .= '</span>';
					}
					$html .= '</div>';
					break;

				default:
					$html .= '<div class="productpageglut-filter-list">';
					foreach ( $terms as $term ) {
						$term_name = is_object( $term ) ? $term->name : $term['name'];
						$term_count = is_object( $term ) ? $term->count : ( isset( $term['count'] ) ? $term['count'] : 0 );

						$html .= '<span class="productpageglut-filter-item">';
						$html .= esc_html( $term_name );
						if ( $show_count ) {
							$html .= ' <span class="count">(' . esc_html( $term_count ) . ')</span>';
						}
						$html .= '</span>';
					}
					$html .= '</div>';
					break;
			}

			return $html;
		}



	}


}